(function () {
  const data = window.JDI_DATA;
  const { getQueryParam, navigate } = window.JDI_COMMON;
  const id = getQueryParam("id");
  const editingItem = data.items.find(it => it.id === id) || null;
  let isDirty = false, pendingLink = null;
  const form = document.getElementById("jdiForm");
  const modalWrap = document.getElementById("leaveModal");
  const secteurSelect = document.getElementById("secteur");
  const typeGainSelect = document.getElementById("typeGain");
  data.sectors.forEach(s => { const o=document.createElement("option");o.value=s;o.textContent=s;secteurSelect.appendChild(o); });
  data.gainTypes.forEach(t => { const o=document.createElement("option");o.value=t;o.textContent=t;typeGainSelect.appendChild(o); });
  function toNumber(v) { const n=Number(v); return Number.isNaN(n)?0:n; }
  function setField(idF,value) { const n=document.getElementById(idF); if(n) n.value=value===null||value===undefined?"":value; }
  function getSelectedGainMode() { const c=document.querySelector("input[name='gainMode']:checked"); return c?c.value:"aucun"; }
  function updateGainModeVisibility() { const m=getSelectedGainMode(); document.getElementById("gainManualFields").style.display=m==="manuel"?"block":"none"; document.getElementById("gainAutoFields").style.display=m==="auto"?"block":"none"; }
  function computeAutoGain() {
    const tg=toNumber(document.getElementById("tempsGagne").value),ut=document.getElementById("uniteTemps").value,occ=toNumber(document.getElementById("nombreOccurrences").value),nb=Math.max(1,toNumber(document.getElementById("nombreOperateurs").value)),ch=toNumber(document.getElementById("coutHoraire").value);
    const mins=(ut==="heure"?tg*60:tg)*occ*nb,hours=Math.round((mins/60)*100)/100,euros=Math.round(hours*ch);
    document.getElementById("autoTimeResult").textContent=`${Math.round(hours)} h`;document.getElementById("autoEuroResult").textContent=`${euros} EUR`;
    return {gainTempsHeures:hours,gainEuro:euros};
  }
  function renderMockPreview(cid,src) { const box=document.getElementById(cid);if(!src){box.innerHTML="";return;}const card=document.createElement("div");card.className="preview-card";card.innerHTML=`<img src="${src}" alt="Apercu"><button type="button" class="btn secondary">Supprimer</button>`;card.querySelector("button").addEventListener("click",()=>{card.remove();isDirty=true;});box.appendChild(card); }
  function bindUpload(inputId,containerId) {
    const input=document.getElementById(inputId),container=document.getElementById(containerId);
    input.addEventListener("change",()=>{Array.from(input.files||[]).forEach(file=>{const reader=new FileReader();reader.onload=e=>{const card=document.createElement("div");card.className="preview-card";card.innerHTML=`<img alt="Image chargee"><button type="button" class="btn secondary">Supprimer</button>`;card.querySelector("img").src=e.target.result;card.querySelector("button").addEventListener("click",()=>{card.remove();isDirty=true;});container.appendChild(card);};reader.readAsDataURL(file);});});
  }
  function updateCharCount(fieldId,counterId,max) { const f=document.getElementById(fieldId),c=document.getElementById(counterId),show=()=>{c.textContent=`${f.value.length}/${max}`;};f.addEventListener("input",show);show(); }
  if (editingItem) {
    document.getElementById("modeLabel").textContent=`Mode edition - ${editingItem.numero}`;
    setField("titre",editingItem.libelle);setField("secteur",editingItem.secteur);setField("statut",editingItem.statut);setField("dateOuverture",editingItem.dateOuverture);setField("dateCloture",editingItem.dateCloture);setField("descAvant",editingItem.descriptionAvant);setField("descApres",editingItem.descriptionApres);setField("conditions",editingItem.conditionsReussite);setField("contributeurs",editingItem.contributeurs);setField("typeGain",editingItem.typeGain||"Autre");
    const mi=document.querySelector(`input[name='gainMode'][value='${editingItem.gainMode||"aucun"}']`);if(mi)mi.checked=true;
    setField("gainTempsManuel",editingItem.gainMode==="manuel"?editingItem.gainTempsHeures:"");setField("gainEuroManuel",editingItem.gainMode==="manuel"?editingItem.gainEuro:"");setField("gainCommentaireManuel",editingItem.gainMode==="manuel"?editingItem.gainCommentaire:"");
    setField("tempsGagne",editingItem.tempsGagne);setField("uniteTemps",editingItem.uniteTemps||"minute");setField("frequence",editingItem.frequence);setField("uniteFrequence",editingItem.uniteFrequence||"semaine");setField("nombreOccurrences",editingItem.nombreOccurrences);setField("nombreOperateurs",editingItem.nombreOperateurs||1);setField("coutHoraire",editingItem.coutHoraire);setField("joursParAn",editingItem.joursParAn);setField("gainCommentaireAuto",editingItem.gainMode==="auto"?editingItem.gainCommentaire:"");
    renderMockPreview("beforePreview",editingItem.imageAvant);renderMockPreview("afterPreview",editingItem.imageApres);
  }
  updateGainModeVisibility();computeAutoGain();
  document.querySelectorAll("input[name='gainMode']").forEach(inp=>inp.addEventListener("change",()=>{updateGainModeVisibility();isDirty=true;}));
  ["tempsGagne","uniteTemps","nombreOccurrences","nombreOperateurs","coutHoraire"].forEach(idF=>{["input","change"].forEach(ev=>document.getElementById(idF).addEventListener(ev,()=>{computeAutoGain();isDirty=true;}));});
  updateCharCount("descAvant","countAvant",600);updateCharCount("descApres","countApres",600);updateCharCount("conditions","countConditions",400);
  bindUpload("imgAvant","beforePreview");bindUpload("imgApres","afterPreview");
  form.addEventListener("input",()=>{isDirty=true;});form.addEventListener("change",()=>{isDirty=true;});
  form.addEventListener("submit",e=>{
    e.preventDefault();const mode=getSelectedGainMode();let eg=0,et=0,gc="";
    if(mode==="manuel"){et=toNumber(document.getElementById("gainTempsManuel").value);eg=toNumber(document.getElementById("gainEuroManuel").value);gc=document.getElementById("gainCommentaireManuel").value.trim();}
    else if(mode==="auto"){const c=computeAutoGain();et=c.gainTempsHeures;eg=c.gainEuro;gc=document.getElementById("gainCommentaireAuto").value.trim();}
    const payload={id:editingItem?editingItem.id:"NOUVEAU",libelle:document.getElementById("titre").value.trim(),secteur:document.getElementById("secteur").value,statut:document.getElementById("statut").value,dateOuverture:document.getElementById("dateOuverture").value,dateCloture:document.getElementById("dateCloture").value,descriptionAvant:document.getElementById("descAvant").value.trim(),descriptionApres:document.getElementById("descApres").value.trim(),conditionsReussite:document.getElementById("conditions").value.trim(),contributeurs:document.getElementById("contributeurs").value.trim(),typeGain:document.getElementById("typeGain").value,gainMode:mode,gainTempsHeures:et,gainEuro:eg,gainCommentaire:gc};
    console.log("Simulation enregistrement JDI",payload);isDirty=false;alert(`JDI enregistre (simulation locale). Mode gain: ${mode}.`);navigate("liste.html");
  });
  document.getElementById("cancelBtn").addEventListener("click",()=>{if(isDirty){pendingLink="liste.html";modalWrap.style.display="flex";return;}navigate("liste.html");});
  document.querySelectorAll("a[data-guard='true']").forEach(link=>link.addEventListener("click",e=>{if(!isDirty)return;e.preventDefault();pendingLink=link.getAttribute("href");modalWrap.style.display="flex";}));
  document.getElementById("stayBtn").addEventListener("click",()=>{modalWrap.style.display="none";pendingLink=null;});
  document.getElementById("leaveBtn").addEventListener("click",()=>{isDirty=false;if(pendingLink)navigate(pendingLink);});
  window.addEventListener("beforeunload",e=>{if(!isDirty)return;e.preventDefault();e.returnValue="";});
})();
