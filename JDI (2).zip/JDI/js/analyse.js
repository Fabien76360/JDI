(function () {
  const { items, sectors, appConfig } = window.JDI_DATA;
  const { formatDate, navigate } = window.JDI_COMMON;
  const voteState = (() => { try { return JSON.parse(localStorage.getItem("jdi_vote_state")) || window.JDI_DATA.vote; } catch(e) { return window.JDI_DATA.vote; } })();
  const fiscalStartMonth = (appConfig && appConfig.fiscalStartMonth) || 4;

  const els = {
    periodPreset: document.getElementById("periodPreset"),
    customDates:  document.getElementById("customDates"),
    customStart:  document.getElementById("customStart"),
    customEnd:    document.getElementById("customEnd"),
    applyPeriod:  document.getElementById("applyPeriod"),
    periodLabel:  document.getElementById("periodLabel"),
    periodCompareLabel: document.getElementById("periodCompareLabel"),
    compareN1:    document.getElementById("compareN1")
  };

  function parseIso(iso) { if(!iso)return null; const d=new Date(`${iso}T00:00:00`); return Number.isNaN(d.getTime())?null:d; }
  function toIso(date) { const y=date.getFullYear(),m=`${date.getMonth()+1}`.padStart(2,"0"),d=`${date.getDate()}`.padStart(2,"0"); return `${y}-${m}-${d}`; }
  function firstDayOfMonth(date) { return new Date(date.getFullYear(),date.getMonth(),1); }
  function lastDayOfMonth(date)  { return new Date(date.getFullYear(),date.getMonth()+1,0); }
  function daysBetween(s,e) { const a=parseIso(s),b=parseIso(e); if(!a||!b)return null; return Math.round((b-a)/86400000); }
  function ageInDays(s) { const a=parseIso(s); if(!a)return null; return Math.max(0,Math.round((new Date()-a)/86400000)); }
  function pct(p,t) { return t?`${Math.round((p/t)*100)}%`:"0%"; }
  function getCurrentFiscalStartYear(ref) { const y=ref.getFullYear(),m=ref.getMonth()+1; return m>=fiscalStartMonth?y:y-1; }
  function buildFiscalRange(startYear) { return { start:new Date(startYear,fiscalStartMonth-1,1), end:new Date(startYear+1,fiscalStartMonth-1,0), label:`Annee fiscale ${startYear}/${startYear+1}` }; }

  function resolvePeriod() {
    const p=els.periodPreset.value, now=new Date();
    if(p==="currentFY")  return buildFiscalRange(getCurrentFiscalStartYear(now));
    if(p==="previousFY") return buildFiscalRange(getCurrentFiscalStartYear(now)-1);
    if(p==="last12") return { start:new Date(now.getFullYear(),now.getMonth()-11,1), end:now, label:"12 derniers mois" };
    const cs=parseIso(els.customStart.value),ce=parseIso(els.customEnd.value);
    if(!cs||!ce||cs>ce) return buildFiscalRange(getCurrentFiscalStartYear(now));
    return { start:cs, end:ce, label:"Periode personnalisee" };
  }

  function shiftYear(range,d) { return { start:new Date(range.start.getFullYear()+d,range.start.getMonth(),range.start.getDate()), end:new Date(range.end.getFullYear()+d,range.end.getMonth(),range.end.getDate()) }; }
  function inRange(iso,range) { const d=parseIso(iso); return Boolean(d&&d>=range.start&&d<=range.end); }

  function setSub(id,txt) { const el=document.getElementById(id+"Sub"); if(el) el.textContent=txt; }

  function renderPeriodLabel(range,rows) {
    els.periodLabel.textContent=`Periode : ${range.label}  —  du ${formatDate(toIso(range.start))} au ${formatDate(toIso(range.end))}`;
    if(!els.compareN1.checked){els.periodCompareLabel.textContent="";return;}
    const n1r=shiftYear(range,-1),n1rows=items.filter(it=>inRange(it.dateOuverture,n1r));
    const delta=rows.length-n1rows.length,sign=delta>=0?"+":"";
    els.periodCompareLabel.textContent=`N-1 sur meme periode : ${n1rows.length} JDI (${sign}${delta} vs periode actuelle)`;
  }

  function renderKpis(rows,range) {
    const open=rows.filter(it=>it.statut==="En cours").length;
    const done=rows.filter(it=>it.statut==="Complété").length;
    const canceled=rows.filter(it=>it.statut==="Annulé").length;
    const cip=items.filter(it=>it.statut==="Complété"&&inRange(it.dateCloture,range));
    const cd=cip.map(it=>daysBetween(it.dateOuverture,it.dateCloture)).filter(v=>v!==null&&v>=0);
    const oa=rows.filter(it=>it.statut==="En cours").map(it=>ageInDays(it.dateOuverture)).filter(v=>v!==null);
    const avgC=cd.length?Math.round(cd.reduce((s,v)=>s+v,0)/cd.length):0;
    const avgO=oa.length?Math.round(oa.reduce((s,v)=>s+v,0)/oa.length):0;
    const mc=Math.max(1,(range.end.getFullYear()-range.start.getFullYear())*12+(range.end.getMonth()-range.start.getMonth())+1);
    const total=rows.length;

    document.getElementById("kpiTotal").textContent    = total;
    document.getElementById("kpiOpen").textContent     = open;
    document.getElementById("kpiDone").textContent     = done;
    document.getElementById("kpiCanceled").textContent = canceled;
    document.getElementById("kpiCloseRate").textContent     = pct(done+canceled,total);
    document.getElementById("kpiAvgCloseDays").textContent  = `${avgC} j`;
    document.getElementById("kpiAvgOpenAge").textContent    = `${avgO} j`;
    document.getElementById("kpiDonePerMonth").textContent  = Math.round(done/mc);
    document.getElementById("kpiConversion").textContent    = pct(done,total);

    // Sous-libelles contextuels
    setSub("kpiTotal",    `sur ${items.length} JDI au total`);
    setSub("kpiOpen",     `${pct(open,total)} du total`);
    setSub("kpiDone",     `${pct(done,total)} du total`);
    setSub("kpiCanceled", `${pct(canceled,total)} du total`);
    setSub("kpiCloseRate",`${done+canceled} cloturus / ${total} ouverts`);
    setSub("kpiConversion",`${done} complete(s) / ${total} ouvert(s)`);
  }

  function renderSimpleBars(cid,rows) {
    const root=document.getElementById(cid); root.innerHTML="";
    const max=Math.max(...rows.map(r=>r.value),1);
    const fills=[];
    rows.forEach(r=>{
      const targetW=Math.round((r.value/max)*100);
      const row=document.createElement("div");row.className="analyse-bar-row";
      row.innerHTML=`<div class="analyse-bar-label">${r.label}</div><div class="analyse-bar-track"><div class="analyse-bar-fill ${r.cls||""}" style="width:0%"></div></div><div class="analyse-bar-value">${r.value}</div>`;
      root.appendChild(row);
      fills.push({el:row.querySelector(".analyse-bar-fill"),w:targetW});
    });
    // Declenche la transition CSS apres le premier rendu
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      fills.forEach(({el,w})=>{ el.style.width=w+"%"; });
    }));
  }

  function renderImpact(range) {
    const gr=items.filter(it=>it.statut==="Complété"&&inRange(it.dateCloture,range));
    const manual=gr.filter(it=>it.gainMode==="manuel");
    const auto=gr.filter(it=>it.gainMode==="auto");
    const none=gr.filter(it=>it.gainMode==="aucun");
    const wg=gr.filter(it=>it.gainMode!=="aucun");
    const th=wg.reduce((s,it)=>s+Number(it.gainTempsHeures||0),0);
    const te=wg.reduce((s,it)=>s+Number(it.gainEuro||0),0);
    const avg=wg.length?Math.round(te/wg.length):0;
    const top=wg.slice().sort((a,b)=>b.gainEuro-a.gainEuro)[0];

    document.getElementById("impactTime").textContent  = `${Math.round(th)} h`;
    document.getElementById("impactEuro").textContent  = `${Math.round(te).toLocaleString("fr")} EUR`;
    document.getElementById("impactCount").textContent = wg.length;
    document.getElementById("impactTop").textContent   = top?`${top.numero} — ${Math.round(top.gainEuro)} EUR`:"-";
    document.getElementById("modeManual").textContent  = `Manuel : ${manual.length}`;
    document.getElementById("modeAuto").textContent    = `Automatique : ${auto.length}`;
    document.getElementById("modeNone").textContent    = `Sans chiffrage : ${none.length}`;
    document.getElementById("impactAvg").textContent   = `Gain moyen / JDI : ${avg} EUR`;
    const sub=document.getElementById("impactEuroSub");
    if(sub) sub.textContent=`${wg.length} JDI chiffres sur ${gr.length} completes`;

    const tm={};wg.forEach(it=>{const k=it.typeGain||"Autre";tm[k]=(tm[k]||0)+1;});
    renderSimpleBars("gainTypeBars",Object.keys(tm).map(k=>({label:k,value:tm[k]})));
  }

  function renderSectorStack(rows) {
    const root=document.getElementById("sectorStack"); root.innerHTML="";
    const fills=[];
    sectors.forEach(s=>{
      const done=rows.filter(it=>it.secteur===s&&it.statut==="Complété").length;
      const open=rows.filter(it=>it.secteur===s&&it.statut==="En cours").length;
      const canceled=rows.filter(it=>it.secteur===s&&it.statut==="Annulé").length;
      const total=done+open+canceled,denom=total||1;
      const dPct=Math.round((done/denom)*100),oPct=Math.round((open/denom)*100),cPct=100-dPct-oPct;
      const row=document.createElement("div");row.className="analyse-stack-row";
      row.innerHTML=`<div class="analyse-stack-label">${s}</div><div class="analyse-stack-track"><span class="stack done" style="width:0%"></span><span class="stack open" style="width:0%"></span><span class="stack cancel" style="width:0%"></span></div><div class="analyse-stack-value">${total}</div>`;
      root.appendChild(row);
      const spans=row.querySelectorAll(".stack");
      fills.push({d:spans[0],o:spans[1],c:spans[2],dPct,oPct,cPct});
    });
    const leg=document.createElement("div");leg.className="analyse-legend";leg.innerHTML="<span><i class='chip done'></i>Complété</span><span><i class='chip open'></i>En cours</span><span><i class='chip cancel'></i>Annulé</span>";root.appendChild(leg);
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      fills.forEach(({d,o,c,dPct,oPct,cPct})=>{d.style.width=dPct+"%";o.style.width=oPct+"%";c.style.width=cPct+"%";});
    }));
  }

  function renderStatusBars(rows) {
    renderSimpleBars("statusBars",[
      {label:"En cours",value:rows.filter(it=>it.statut==="En cours").length,cls:"warn"},
      {label:"Complété",value:rows.filter(it=>it.statut==="Complété").length,cls:"ok"},
      {label:"Annulé",value:rows.filter(it=>it.statut==="Annulé").length,cls:"cancel"}
    ]);
  }

  function renderMonthlyFlow(range) {
    const root=document.getElementById("monthlyFlow");root.innerHTML="";
    const months=[];let cur=firstDayOfMonth(range.start);
    while(cur<=firstDayOfMonth(range.end)){months.push(new Date(cur));cur=new Date(cur.getFullYear(),cur.getMonth()+1,1);}
    const rows=months.map(m=>{
      const key=`${m.getFullYear()}-${`${m.getMonth()+1}`.padStart(2,"0")}`,end=lastDayOfMonth(m);
      const created=items.filter(it=>(it.dateOuverture||"").startsWith(key)).length;
      const closed=items.filter(it=>(it.dateCloture||"").startsWith(key)).length;
      const backlog=items.filter(it=>{const o=parseIso(it.dateOuverture),c=parseIso(it.dateCloture);return o&&o<=end&&(!c||c>end);}).length;
      return {label:`${`${m.getMonth()+1}`.padStart(2,"0")}/${m.getFullYear()}`,created,closed,backlog};
    });
    const max=Math.max(...rows.map(r=>Math.max(r.created,r.closed,r.backlog)),1);
    const fills=[];
    rows.forEach(r=>{
      const row=document.createElement("div");row.className="analyse-month-row";
      row.innerHTML=`<div class="analyse-month-label">${r.label}</div><div class="analyse-month-triple"><span class="bar created" style="width:0%"></span><span class="bar closed" style="width:0%"></span><span class="bar backlog" style="width:0%"></span></div><div class="analyse-month-value">C${r.created}/Cl${r.closed}/B${r.backlog}</div>`;
      root.appendChild(row);
      const spans=row.querySelectorAll(".bar");
      fills.push({c:spans[0],cl:spans[1],b:spans[2],cW:Math.round((r.created/max)*100),clW:Math.round((r.closed/max)*100),bW:Math.round((r.backlog/max)*100)});
    });
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      fills.forEach(({c,cl,b,cW,clW,bW})=>{c.style.width=cW+"%";cl.style.width=clW+"%";b.style.width=bW+"%";});
    }));
  }

  function renderFollowTable(range) {
    const rows=items.filter(it=>it.statut==="En cours"&&parseIso(it.dateOuverture)&&parseIso(it.dateOuverture)<=range.end)
      .map(it=>({...it,age:ageInDays(it.dateOuverture)||0})).sort((a,b)=>b.age-a.age).slice(0,10);
    const body=document.getElementById("followRows");body.innerHTML="";
    if(!rows.length){body.innerHTML="<tr><td colspan='8' class='table-empty'>Aucun JDI en cours sur la periode</td></tr>";return;}
    rows.forEach(it=>{
      const tr=document.createElement("tr");tr.className=it.age>60?"age-high":it.age>=30?"age-mid":"age-normal";
      tr.innerHTML=`<td class="mono">${it.numero}</td><td>${it.libelle}</td><td>${it.secteur}</td><td>${formatDate(it.dateOuverture)}</td><td>${it.age} j</td><td><span class="badge en-cours">En cours</span></td><td>${it.responsable||"-"}</td><td>${Math.round(it.gainEuro||0)} EUR</td>`;
      tr.addEventListener("click",()=>navigate(`itemvisu.html?id=${encodeURIComponent(it.id)}`));
      body.appendChild(tr);
    });
  }

  function scoreCompleteness(it) {
    let s=100;if(!it.descriptionApres)s-=20;if(!it.presenceImagesAvant||!it.presenceImagesApres)s-=20;if(!it.contributeurs)s-=20;if(it.gainMode==="aucun")s-=20;if(it.statut==="Complété"&&!it.dateCloture)s-=20;return Math.max(0,s);
  }

  function renderQualityTable(rows) {
    const qrows=rows.map(it=>{
      const reasons=[],delay=daysBetween(it.dateOuverture,it.dateCloture);let level="";
      if((it.dateCloture&&delay!==null&&delay<0)||(it.statut==="Complété"&&!it.dateCloture)){level="Critique";reasons.push("Dates/statut incoherents");}
      else if(it.gainMode==="aucun"||!(it.contributeurs||"").trim()){level="Important";if(it.gainMode==="aucun")reasons.push("Sans gain chiffre");if(!(it.contributeurs||"").trim())reasons.push("Sans contributeur");}
      else if(!it.presenceImagesAvant||!it.presenceImagesApres||!(it.descriptionApres||"").trim()){level="Qualite";if(!it.presenceImagesAvant||!it.presenceImagesApres)reasons.push("Sans image");if(!(it.descriptionApres||"").trim())reasons.push("Sans description apres");}
      return {...it,level,reasons,score:scoreCompleteness(it)};
    }).filter(it=>it.level).sort((a,b)=>({Critique:3,Important:2,Qualite:1}[b.level]-{Critique:3,Important:2,Qualite:1}[a.level])).slice(0,12);
    const body=document.getElementById("qualityRows");body.innerHTML="";
    if(!qrows.length){body.innerHTML="<tr><td colspan='5' class='table-empty'>Aucune alerte qualite sur la periode</td></tr>";return;}
    qrows.forEach(it=>{
      const cls=it.level==="Critique"?"level-critical":it.level==="Important"?"level-important":"level-quality";
      const tr=document.createElement("tr");
      tr.innerHTML=`<td><span class="severity ${cls}">${it.level}</span></td><td class="mono">${it.numero}</td><td>${it.libelle}</td><td>${it.reasons.join(", ")}</td><td>${it.score}%</td>`;
      tr.addEventListener("click",()=>navigate(`formulaire.html?id=${encodeURIComponent(it.id)}`));
      body.appendChild(tr);
    });
  }

  function renderHighlights(range) {
    const cards=items.filter(it=>it.statut==="Complété"&&inRange(it.dateCloture,range)).sort((a,b)=>a.dateCloture<b.dateCloture?1:-1).slice(0,3);
    const root=document.getElementById("highlightCards");root.innerHTML=cards.length?"":"<div class='info-box'>Aucune valorisation sur la periode.</div>";
    cards.forEach(it=>{
      const nominated=voteState.months.filter(m=>(m.nominations||[]).includes(it.id)).map(m=>m.key);
      const elected=voteState.months.some(m=>{if(m.statutScrutin!=="cloture"||!(m.nominations||[]).length)return false;const t={};m.nominations.forEach(id=>{t[id]=0;});(m.votes||[]).forEach(v=>{if(t[v.jdiId]!==undefined)t[v.jdiId]++;});const w=Object.keys(t).sort((a,b)=>t[b]-t[a])[0];return t[w]>0&&w===it.id;});
      const badge=elected?`<span class="jdi-medal">&#127942; JDI du mois</span>`:nominated.length?`<span class="jdi-nominated">Nomme</span>`:"";
      const card=document.createElement("article");card.className="highlight-card";
      card.innerHTML=`
        <div class="highlight-head mono">${it.numero} &mdash; <span style="font-size:11px;">${it.secteur}</span></div>
        <div class="highlight-title">${it.libelle}</div>
        ${badge}
        <div class="highlight-meta" style="margin-top:6px;">Type de gain : ${it.typeGain}</div>
        <div class="highlight-gain">${Math.round(it.gainEuro||0).toLocaleString("fr")} EUR &bull; ${Math.round(it.gainTempsHeures||0)} h</div>
        <div class="highlight-images">
          ${it.imageAvant?`<div><div class="form-note" style="margin-bottom:3px;">Avant</div><img src="${it.imageAvant}" alt="Avant"></div>`:""}
          ${it.imageApres?`<div><div class="form-note" style="margin-bottom:3px;">Apres</div><img src="${it.imageApres}" alt="Apres"></div>`:""}
        </div>`;
      card.addEventListener("click",()=>navigate(`itemvisu.html?id=${encodeURIComponent(it.id)}`));
      root.appendChild(card);
    });
  }

  function refresh() {
    const range=resolvePeriod(),rows=items.filter(it=>inRange(it.dateOuverture,range));
    renderPeriodLabel(range,rows);renderKpis(rows,range);renderImpact(range);renderSectorStack(rows);renderStatusBars(rows);renderMonthlyFlow(range);renderFollowTable(range);renderQualityTable(rows);renderHighlights(range);
  }

  // FIX : utiliser classList pour ne pas etre bloque par .hidden { display:none !important }
  els.periodPreset.addEventListener("change",()=>{
    const isCustom=els.periodPreset.value==="custom";
    if(isCustom){ els.customDates.classList.remove("hidden"); }
    else { els.customDates.classList.add("hidden"); refresh(); }
  });
  els.applyPeriod.addEventListener("click",refresh);
  els.compareN1.addEventListener("change",refresh);

  const now=new Date(),dr=buildFiscalRange(getCurrentFiscalStartYear(now));
  els.customStart.value=toIso(dr.start);els.customEnd.value=toIso(dr.end);
  refresh();
})();
