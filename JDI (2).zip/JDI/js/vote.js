(function () {
  const ACCESS_KEY="jdi_vote_access",STATE_KEY="jdi_vote_state";
  const data=window.JDI_DATA,{navigate}=window.JDI_COMMON;
  const accessZone=document.getElementById("voteAccessZone"),contentZone=document.getElementById("voteContent"),passwordInput=document.getElementById("votePassword"),accessMsg=document.getElementById("voteAccessMsg");
  const monthSelect=document.getElementById("voteMonthSelect"),statusSelect=document.getElementById("voteStatusSelect"),statusInfo=document.getElementById("voteStatusInfo");
  const nominationList=document.getElementById("nominationList"),voteCandidates=document.getElementById("voteCandidates");
  const voteUserSelect=document.getElementById("voteUserSelect"),voteJustification=document.getElementById("voteJustification");
  const voteResultRows=document.getElementById("voteResultRows"),voteWinnerBanner=document.getElementById("voteWinnerBanner"),voteJustifs=document.getElementById("voteJustifs"),qualifiedRows=document.getElementById("qualifiedRows");

  function loadState(){try{const r=localStorage.getItem(STATE_KEY);if(!r)return JSON.parse(JSON.stringify(data.vote));return JSON.parse(r);}catch(e){return JSON.parse(JSON.stringify(data.vote));}}
  let state=loadState();
  function saveState(){localStorage.setItem(STATE_KEY,JSON.stringify(state));}
  function isAuthorized(){return sessionStorage.getItem(ACCESS_KEY)==="1";}
  function setAuthorized(a){if(a)sessionStorage.setItem(ACCESS_KEY,"1");else sessionStorage.removeItem(ACCESS_KEY);}
  function showContent(){accessZone.classList.add("hidden");contentZone.classList.remove("hidden");}
  function showAccess(){contentZone.classList.add("hidden");accessZone.classList.remove("hidden");}
  function getMonthState(){return state.months.find(m=>m.key===monthSelect.value)||state.months[0];}
  function getItem(id){return data.items.find(it=>it.id===id);}

  function computeMonthResults(month){
    const c={};month.nominations.forEach(id=>{c[id]=0;});month.votes.forEach(v=>{if(c[v.jdiId]===undefined)c[v.jdiId]=0;c[v.jdiId]++;});
    let w="",max=-1;Object.keys(c).forEach(id=>{if(c[id]>max){max=c[id];w=id;}});
    if(month.statutScrutin!=="cloture")w="";
    return{counts:c,winnerId:max>0?w:""};
  }
  function getElectedIds(){const ids=new Set();state.months.forEach(m=>{const r=computeMonthResults(m);if(m.statutScrutin==="cloture"&&r.winnerId)ids.add(r.winnerId);});return ids;}

  function renderMonthOptions(){
    monthSelect.innerHTML="";
    state.months.forEach(m=>{const o=document.createElement("option");o.value=m.key;o.textContent=m.label;monthSelect.appendChild(o);});
    monthSelect.value=state.months[state.months.length-1].key;
  }
  function renderStatus(){const m=getMonthState();statusSelect.value=m.statutScrutin;statusInfo.textContent=`Acces autorise. Periode : ${m.debutScrutin||"-"} au ${m.finScrutin||"-"}`;}

  // FILTRE NOMINATIONS : Completes par defaut, toggle pour voir tous
  function renderNominations(){
    const month=getMonthState();nominationList.innerHTML="";const ei=getElectedIds();
    const showAll=document.getElementById("nomShowAll")?.checked||false;
    const displayItems=data.items.filter(item=>showAll||item.statut==="Complété");
    if(!displayItems.length){nominationList.innerHTML="<div class='info-box'>Aucun JDI disponible.</div>";return;}
    displayItems.forEach(item=>{
      const isN=month.nominations.includes(item.id),isE=ei.has(item.id);
      const row=document.createElement("label");row.className="vote-list-row";
      const statusCls=item.statut==="Complété"?"complete":item.statut==="Annulé"?"annule":"en-cours";
      row.innerHTML=`<input type="checkbox" ${isN?"checked":""} ${isE?"disabled":""} data-id="${item.id}"><span class="mono">${item.numero}</span><span>${item.libelle}</span><span class="badge ${statusCls}">${item.statut}</span>${isE?"<span class='severity level-quality'>Deja elu</span>":""}`;
      const input=row.querySelector("input");
      input.addEventListener("change",()=>{
        if(input.checked&&!month.nominations.includes(item.id))month.nominations.push(item.id);
        if(!input.checked){month.nominations=month.nominations.filter(id=>id!==item.id);month.votes=month.votes.filter(v=>v.jdiId!==item.id);}
        saveState();renderAll();
      });
      nominationList.appendChild(row);
    });
  }

  // CANDIDATS EN CARTES cliquables
  function renderVoteCandidates(){
    const month=getMonthState(),cu=voteUserSelect.value,existing=month.votes.find(v=>v.utilisateur===cu);
    voteCandidates.innerHTML="";
    if(!month.nominations.length){voteCandidates.innerHTML="<div class='info-box'>Aucun JDI nomine pour ce mois. Utilisez la section Nomination ci-dessus.</div>";return;}
    const isClosed=month.statutScrutin==="cloture";
    const grid=document.createElement("div");grid.className="vote-candidates-grid";
    month.nominations.forEach(id=>{
      const item=getItem(id);if(!item)return;
      const isSelected=existing&&existing.jdiId===id;
      const card=document.createElement("div");
      card.className=`vote-candidate-card${isSelected?" selected":""}${isClosed?" locked":""}`;
      const gainTxt=item.gainMode==="aucun"?"Gain non chiffre":`${Math.round(item.gainEuro||0).toLocaleString("fr")} EUR / ${Math.round(item.gainTempsHeures||0)} h`;
      card.innerHTML=`
        <input type="radio" class="vote-radio-hidden" name="voteChoice" value="${id}" ${isSelected?"checked":""} ${isClosed?"disabled":""} style="position:absolute;opacity:0;pointer-events:none;">
        <div class="vote-candidate-card-header">
          <span class="vote-candidate-num">${item.numero}</span>
          <span class="badge complete">${item.statut}</span>
        </div>
        <div class="vote-candidate-title">${item.libelle}</div>
        <div class="vote-candidate-meta">${item.secteur} &bull; ${item.typeGain}</div>
        <div class="vote-candidate-gain">${gainTxt}</div>
        <div style="margin-top:8px;"><a class="btn secondary" style="font-size:11px;padding:3px 8px;" href="itemvisu.html?id=${encodeURIComponent(id)}">Voir la fiche</a></div>`;
      if(!isClosed){
        card.addEventListener("click",(e)=>{
          if(e.target.tagName==="A")return;
          document.querySelectorAll(".vote-candidate-card").forEach(c=>c.classList.remove("selected"));
          card.classList.add("selected");
          card.querySelector("input[type='radio']").checked=true;
        });
      }
      grid.appendChild(card);
    });
    voteCandidates.appendChild(grid);
    voteJustification.value=existing?existing.justification:"";
  }

  function renderResults(){
    const month=getMonthState(),{counts,winnerId}=computeMonthResults(month);
    voteResultRows.innerHTML="";
    if(!month.nominations.length){voteResultRows.innerHTML="<tr><td colspan='4' class='table-empty'>Aucun JDI nomine ce mois</td></tr>";}
    else{
      month.nominations.forEach(id=>{
        const item=getItem(id);if(!item)return;
        const tr=document.createElement("tr");
        tr.innerHTML=`<td class="mono">${item.numero} — ${item.libelle}</td><td>${item.secteur}</td><td><strong>${counts[id]||0}</strong></td><td>${winnerId===id?"<span class='severity level-important'>Gagnant du mois</span>":"-"}</td>`;
        tr.addEventListener("click",()=>navigate(`itemvisu.html?id=${encodeURIComponent(id)}`));
        voteResultRows.appendChild(tr);
      });
    }
    // Banniere winner
    if(winnerId&&month.statutScrutin==="cloture"){
      const wi=getItem(winnerId);
      voteWinnerBanner.className="vote-winner-banner";
      voteWinnerBanner.innerHTML=`<div class="vote-winner-icon">&#127942;</div><div class="vote-winner-text"><strong>JDI du mois : ${wi.numero}</strong><span>${wi.libelle} &mdash; ${wi.secteur} &mdash; ${Math.round(wi.gainEuro||0)} EUR</span></div>`;
    } else {
      voteWinnerBanner.className="info-box vote-gap-top";
      voteWinnerBanner.textContent=month.statutScrutin==="cloture"?"Aucun vote enregistre pour ce mois.":"Scrutin en cours. Le gagnant sera affiche apres cloture.";
    }
    // Justifications
    if(!month.votes.length){
      voteJustifs.style.display="none";
    } else {
      voteJustifs.style.display="block";
      voteJustifs.innerHTML=`<strong style="display:block;margin-bottom:6px;">Justifications :</strong>`+month.votes.map(v=>`<div style="padding:4px 0;border-bottom:1px solid var(--c-border);"><span class="mono" style="font-size:11px;">${v.utilisateur}</span> &mdash; ${v.justification}</div>`).join("");
    }
  }

  function renderQualified(){
    qualifiedRows.innerHTML="";
    let found=false;
    state.months.forEach(month=>{
      const{winnerId}=computeMonthResults(month);
      if(month.statutScrutin!=="cloture"||!winnerId)return;
      const item=getItem(winnerId);if(!item)return;
      found=true;
      const tr=document.createElement("tr");
      tr.innerHTML=`<td>${month.label}</td><td class="mono">${item.numero}</td><td>${item.libelle}</td><td>${item.secteur}</td><td>${item.typeGain} / ${Math.round(item.gainEuro||0)} EUR</td>`;
      tr.addEventListener("click",()=>navigate(`itemvisu.html?id=${encodeURIComponent(item.id)}`));
      qualifiedRows.appendChild(tr);
    });
    if(!found) qualifiedRows.innerHTML="<tr><td colspan='5' class='table-empty'>Aucun JDI elu pour le moment</td></tr>";
  }

  function renderAll(){renderStatus();renderNominations();renderVoteCandidates();renderResults();renderQualified();}

  document.getElementById("voteLoginBtn").addEventListener("click",()=>{
    if(passwordInput.value===state.password){
      setAuthorized(true);accessMsg.textContent="";showContent();
      renderMonthOptions();voteUserSelect.innerHTML=data.users.map(u=>`<option value="${u}">${u}</option>`).join("");
      renderAll();return;
    }
    accessMsg.textContent="Mot de passe incorrect.";
    passwordInput.focus();
  });
  document.getElementById("voteLogoutBtn").addEventListener("click",()=>{setAuthorized(false);showAccess();passwordInput.value="";});
  monthSelect.addEventListener("change",renderAll);
  statusSelect.addEventListener("change",()=>{const m=getMonthState();m.statutScrutin=statusSelect.value;saveState();renderAll();});
  voteUserSelect.addEventListener("change",renderVoteCandidates);
  document.getElementById("nomShowAll")?.addEventListener("change",()=>{if(isAuthorized())renderNominations();});

  document.getElementById("saveVoteBtn").addEventListener("click",()=>{
    const month=getMonthState();
    if(month.statutScrutin==="cloture"){alert("Le scrutin est cloture. Vote non modifiable.");return;}
    const choice=document.querySelector("input[name='voteChoice']:checked"),justification=voteJustification.value.trim();
    if(!choice){alert("Selectionner un JDI nomine en cliquant sur une carte.");return;}
    if(!justification){alert("La justification est obligatoire.");return;}
    const user=voteUserSelect.value,ei=month.votes.findIndex(v=>v.utilisateur===user);
    const payload={utilisateur:user,jdiId:choice.value,justification};
    if(ei>=0)month.votes[ei]=payload;else month.votes.push(payload);
    saveState();renderAll();alert("Vote enregistre avec succes.");
  });

  // Touche Entree sur le champ mot de passe
  passwordInput.addEventListener("keydown",e=>{if(e.key==="Enter")document.getElementById("voteLoginBtn").click();});

  if(isAuthorized()){
    showContent();
    renderMonthOptions();voteUserSelect.innerHTML=data.users.map(u=>`<option value="${u}">${u}</option>`).join("");
    renderAll();
  }
})();
