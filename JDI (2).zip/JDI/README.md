# JDI

Ouvrir index.html dans un navigateur pour demarrer l'application.
