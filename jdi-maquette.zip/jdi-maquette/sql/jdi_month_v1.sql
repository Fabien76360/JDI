CREATE TABLE jdi_month_cycle (
  id_cycle VARCHAR(40) PRIMARY KEY,
  year INTEGER NOT NULL,
  month INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
  label VARCHAR(50) NOT NULL,
  status VARCHAR(20) NOT NULL,
  candidacy_open_date DATE,
  candidacy_close_date DATE,
  vote_open_date DATE,
  vote_close_date DATE,
  winner_jdi_id VARCHAR(40),
  CONSTRAINT uq_jdi_month_cycle UNIQUE (year, month),
  CONSTRAINT fk_jdi_month_cycle_winner
    FOREIGN KEY (winner_jdi_id) REFERENCES JDI(id_jdi)
);

CREATE TABLE jdi_month_candidate (
  id_candidate VARCHAR(60) PRIMARY KEY,
  id_cycle VARCHAR(40) NOT NULL,
  id_jdi VARCHAR(40) NOT NULL,
  id_secteur VARCHAR(80) NOT NULL,
  proposed_by_user VARCHAR(120) NOT NULL,
  proposed_at TIMESTAMP NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  CONSTRAINT fk_jdi_month_candidate_cycle
    FOREIGN KEY (id_cycle) REFERENCES jdi_month_cycle(id_cycle),
  CONSTRAINT fk_jdi_month_candidate_jdi
    FOREIGN KEY (id_jdi) REFERENCES JDI(id_jdi),
  CONSTRAINT uq_jdi_month_candidate_sector UNIQUE (id_cycle, id_secteur)
);

CREATE TABLE jdi_month_vote (
  id_vote VARCHAR(60) PRIMARY KEY,
  id_cycle VARCHAR(40) NOT NULL,
  id_candidate VARCHAR(60) NOT NULL,
  voter_identifier VARCHAR(120) NOT NULL,
  justification_text TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL,
  CONSTRAINT fk_jdi_month_vote_cycle
    FOREIGN KEY (id_cycle) REFERENCES jdi_month_cycle(id_cycle),
  CONSTRAINT fk_jdi_month_vote_candidate
    FOREIGN KEY (id_candidate) REFERENCES jdi_month_candidate(id_candidate),
  CONSTRAINT uq_jdi_month_vote_voter UNIQUE (id_cycle, voter_identifier)
);
