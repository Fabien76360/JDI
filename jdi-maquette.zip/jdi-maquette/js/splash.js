(function () {
  const SPLASH_DURATION_MS = 2200;
  const TARGET_URL = "dashboard.html";
  let redirected = false;
  let timerId = window.setTimeout(redirectNow, SPLASH_DURATION_MS);

  function redirectNow() {
    if (redirected) {
      return;
    }

    redirected = true;
    window.clearTimeout(timerId);
    window.location.replace(TARGET_URL);
  }

  function handleKeydown(event) {
    if (event.key === "Enter") {
      event.preventDefault();
      redirectNow();
    }
  }

  document.addEventListener("click", redirectNow, { passive: true });
  document.addEventListener("keydown", handleKeydown);
})();
