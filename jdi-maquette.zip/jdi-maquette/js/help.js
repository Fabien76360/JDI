(function () {
  const faqRoot = document.getElementById("faqRoot");

  if (!faqRoot) {
    return;
  }

  const defaultFaq = [
    {
      q: "Je ne sais pas si mon idée est un JDI",
      a: "Si votre idée résout un problème concret, met en place une solution simple et apporte un gain visible, elle peut être déclarée comme JDI."
    },
    {
      q: "Mon JDI concerne plusieurs secteurs",
      a: "Choisissez le secteur principal concerné par la mise en place. Si besoin, précisez les autres secteurs dans la description ou dans les contributeurs."
    },
    {
      q: "Qui puis-je contacter si j'ai besoin d'aide ?",
      a: "En cas de doute, rapprochez-vous de votre référent secteur, de votre responsable ou de la personne qui suit la dynamique JDI sur le site."
    },
    {
      q: "Que devient mon JDI après l'enregistrement ?",
      a: "Le JDI est visible dans la liste, peut être enrichi si nécessaire, puis validé et clôturé une fois l'amélioration mise en place et confirmée."
    },
    {
      q: "Que faire si ma photo est trop lourde ?",
      a: "Gardez seulement l'image utile à la compréhension. Si le fichier est trop volumineux, réduisez-le avant envoi ou transmettez-le via le relais local prévu."
    },
    {
      q: "Faut-il mettre des noms ou des secteurs dans 'Contributeurs' ?",
      a: "Indiquez en priorité les personnes ou équipes ayant participé. Si cela aide à comprendre, vous pouvez compléter avec le service concerné."
    }
  ];

  function uniqueFaq(items) {
    const seen = new Set();

    return items.filter((item) => {
      const question = typeof item.q === "string" ? item.q.trim() : "";
      const answer = typeof item.a === "string" ? item.a.trim() : "";

      if (!question || !answer || seen.has(question)) {
        return false;
      }

      seen.add(question);
      return true;
    });
  }

  const sourceFaq = Array.isArray(window.JDI_DATA && window.JDI_DATA.faq) ? window.JDI_DATA.faq : [];
  const faqItems = uniqueFaq([...defaultFaq, ...sourceFaq]);

  faqItems.forEach((item, index) => {
    const faqId = "helpFaqAnswer" + index;
    const wrap = document.createElement("article");
    wrap.className = "help-faq-item";

    const button = document.createElement("button");
    button.type = "button";
    button.className = "help-faq-question";
    button.setAttribute("aria-expanded", "false");
    button.setAttribute("aria-controls", faqId);
    button.innerHTML = `
      <span class="help-faq-index mono">${String(index + 1).padStart(2, "0")}</span>
      <span class="help-faq-question-text">${item.q}</span>
      <span class="help-faq-toggle" aria-hidden="true">+</span>
    `;

    const answer = document.createElement("div");
    answer.className = "help-faq-answer";
    answer.id = faqId;
    answer.hidden = true;
    answer.innerHTML = `<p>${item.a}</p>`;

    button.addEventListener("click", () => {
      const isOpen = button.getAttribute("aria-expanded") === "true";
      button.setAttribute("aria-expanded", String(!isOpen));
      answer.hidden = isOpen;
    });

    wrap.appendChild(button);
    wrap.appendChild(answer);
    faqRoot.appendChild(wrap);
  });
})();
