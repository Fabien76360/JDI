(function () {
  const data = window.JDI_DATA || {};
  const common = window.JDI_COMMON || {};
  const items = Array.isArray(data.items) ? data.items.slice() : [];
  const configuredSectors = Array.isArray(data.sectors) ? data.sectors : [];
  const configuredGainTypes = Array.isArray(data.gainTypes) ? data.gainTypes : [];
  const formatDate = typeof common.formatDate === "function"
    ? common.formatDate
    : (value) => value || "-";
  const statusMeta = typeof common.statusMeta === "function"
    ? common.statusMeta
    : (status) => ({ label: status || "-", className: "" });
  const navigate = typeof common.navigate === "function"
    ? common.navigate
    : (url) => { window.location.href = url; };
  const getQueryParam = typeof common.getQueryParam === "function"
    ? common.getQueryParam
    : () => "";

  const numberFormatter = new Intl.NumberFormat("fr-FR");
  const currencyFormatter = new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 0
  });

  const els = {
    totalCount: document.getElementById("listTotalCount"),
    rowCount: document.getElementById("rowCount"),
    sortSummary: document.getElementById("sortSummary"),
    search: document.getElementById("searchFilter"),
    sector: document.getElementById("secteurFilter"),
    status: document.getElementById("statutFilter"),
    typeGain: document.getElementById("typeGainFilter"),
    dateFrom: document.getElementById("dateFromFilter"),
    dateTo: document.getElementById("dateToFilter"),
    reset: document.getElementById("resetFiltersBtn"),
    emptyReset: document.getElementById("emptyResetBtn"),
    newJdi: document.getElementById("newJdiBtn"),
    tableWrapper: document.getElementById("tableWrapper"),
    emptyState: document.getElementById("emptyState"),
    tbody: document.getElementById("jdiRows"),
    sortButtons: Array.from(document.querySelectorAll(".list-sort-btn"))
  };

  const sortLabels = {
    title: "titre",
    secteur: "secteur",
    statut: "statut",
    dateOuverture: "date d'ouverture",
    gain: "gain"
  };

  const statusOrder = {
    "En cours": 0,
    "Complété": 1,
    "Annulé": 2
  };

  const state = {
    sortKey: "dateOuverture",
    sortDirection: "desc"
  };

  function normalizeText(value) {
    return (value || "")
      .toString()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .trim();
  }

  function parseIsoDate(isoDate) {
    if (!isoDate) {
      return null;
    }

    const date = new Date(`${isoDate}T00:00:00`);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function formatInteger(value) {
    return numberFormatter.format(Math.round(value || 0));
  }

  function getTitle(item) {
    return item.libelle || item.titre || item.numero || item.id || "JDI sans titre";
  }

  function getGainValue(item) {
    const euro = Number(item.gainEuro);
    const hours = Number(item.gainTempsHeures);
    const validEuro = Number.isFinite(euro) ? euro : 0;
    const validHours = Number.isFinite(hours) ? hours : 0;

    return {
      euro: validEuro,
      hours: validHours
    };
  }

  function formatGain(item) {
    const gainQuantifie = (item.gainQuantifie || "").toString().trim();

    if (gainQuantifie && gainQuantifie !== "N/A") {
      return {
        value: gainQuantifie.replace("EUR", "€"),
        meta: item && item.typeGain ? item.typeGain : "",
        muted: false
      };
    }

    if (!item || item.gainMode === "aucun") {
      return {
        value: "Non renseigné",
        meta: item && item.typeGain ? item.typeGain : "",
        muted: true
      };
    }

    const gain = getGainValue(item);
    const fragments = [];

    if (gain.hours > 0) {
      fragments.push(`${formatInteger(gain.hours)} h`);
    }

    if (gain.euro > 0) {
      fragments.push(currencyFormatter.format(Math.round(gain.euro)));
    }

    if (!fragments.length) {
      return {
        value: "À consolider",
        meta: item.typeGain || "",
        muted: true
      };
    }

    return {
      value: fragments.join(" / "),
      meta: item.typeGain || "",
      muted: false
    };
  }

  function buildOptions(sourceValues) {
    return Array.from(new Set(sourceValues.filter(Boolean))).sort((left, right) => left.localeCompare(right, "fr"));
  }

  function populateSelect(node, values) {
    values.forEach((value) => {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = value;
      node.appendChild(option);
    });
  }

  function initializeFilters() {
    const sectors = buildOptions([
      ...configuredSectors,
      ...items.map((item) => item.secteur)
    ]);
    const statuses = buildOptions(items.map((item) => item.statut));
    const gainTypes = buildOptions([
      ...configuredGainTypes,
      ...items.map((item) => item.typeGain)
    ]);

    populateSelect(els.sector, sectors);
    populateSelect(els.status, statuses);
    populateSelect(els.typeGain, gainTypes);

    els.totalCount.textContent = formatInteger(items.length);

    const initialSector = getQueryParam("secteur") || "";
    const initialStatus = getQueryParam("statut") || "";
    const initialTypeGain = getQueryParam("typeGain") || "";
    const initialSearch = getQueryParam("q") || "";
    const initialDateFrom = getQueryParam("dateFrom") || "";
    const initialDateTo = getQueryParam("dateTo") || "";

    if (initialSector) {
      els.sector.value = initialSector;
    }
    if (initialStatus) {
      els.status.value = initialStatus;
    }
    if (initialTypeGain) {
      els.typeGain.value = initialTypeGain;
    }
    if (initialSearch) {
      els.search.value = initialSearch;
    }
    if (initialDateFrom) {
      els.dateFrom.value = initialDateFrom;
    }
    if (initialDateTo) {
      els.dateTo.value = initialDateTo;
    }
  }

  function passesFilters(item) {
    const query = normalizeText(els.search.value);
    const title = normalizeText(getTitle(item));
    const numero = normalizeText(item.numero || item.id);
    const sector = normalizeText(item.secteur);
    const fromDate = parseIsoDate(els.dateFrom.value);
    const toDate = parseIsoDate(els.dateTo.value);
    const openedAt = parseIsoDate(item.dateOuverture);

    if (query) {
      const haystack = `${title} ${numero} ${sector}`;
      if (!haystack.includes(query)) {
        return false;
      }
    }

    if (els.sector.value && item.secteur !== els.sector.value) {
      return false;
    }

    if (els.status.value && item.statut !== els.status.value) {
      return false;
    }

    if (els.typeGain.value && item.typeGain !== els.typeGain.value) {
      return false;
    }

    if (fromDate && (!openedAt || openedAt < fromDate)) {
      return false;
    }

    if (toDate && (!openedAt || openedAt > toDate)) {
      return false;
    }

    return true;
  }

  function compareValues(left, right) {
    if (left < right) return -1;
    if (left > right) return 1;
    return 0;
  }

  function getSortValue(item, sortKey) {
    if (sortKey === "title") {
      return normalizeText(getTitle(item));
    }

    if (sortKey === "secteur") {
      return normalizeText(item.secteur);
    }

    if (sortKey === "statut") {
      return statusOrder[item.statut] ?? 99;
    }

    if (sortKey === "gain") {
      const gain = getGainValue(item);
      return gain.euro > 0 ? gain.euro : gain.hours;
    }

    const date = parseIsoDate(item.dateOuverture);
    return date ? date.getTime() : 0;
  }

  function sortRows(rows) {
    return rows.slice().sort((left, right) => {
      const leftValue = getSortValue(left, state.sortKey);
      const rightValue = getSortValue(right, state.sortKey);
      const comparison = compareValues(leftValue, rightValue);

      if (comparison !== 0) {
        return state.sortDirection === "asc" ? comparison : comparison * -1;
      }

      return compareValues(
        parseIsoDate(right.dateOuverture)?.getTime() || 0,
        parseIsoDate(left.dateOuverture)?.getTime() || 0
      );
    });
  }

  function updateSortUi() {
    els.sortButtons.forEach((button) => {
      const isActive = button.dataset.sort === state.sortKey;
      const indicator = button.querySelector(".list-sort-indicator");
      const parent = button.closest("th");

      button.classList.toggle("is-active", isActive);
      if (indicator) {
        indicator.textContent = isActive ? (state.sortDirection === "asc" ? "↑" : "↓") : "";
      }

      if (parent) {
        parent.setAttribute(
          "aria-sort",
          isActive ? (state.sortDirection === "asc" ? "ascending" : "descending") : "none"
        );
      }
    });

    els.sortSummary.textContent = `Tri : ${sortLabels[state.sortKey]} ${state.sortDirection === "asc" ? "croissant" : "décroissant"}`;
  }

  function renderRows(rows) {
    els.tbody.innerHTML = "";

    rows.forEach((item) => {
      const row = document.createElement("tr");
      const status = statusMeta(item.statut);
      const gain = formatGain(item);

      row.className = "list-row";
      row.tabIndex = 0;
      row.innerHTML = `
        <td class="list-title-cell">
          <span class="list-item-title">${getTitle(item)}</span>
          <span class="list-item-meta mono">${item.numero || item.id || ""}</span>
        </td>
        <td>${item.secteur || "-"}</td>
        <td><span class="badge ${status.className}">${status.label}</span></td>
        <td class="mono">${formatDate(item.dateOuverture)}</td>
        <td>
          <span class="list-gain-value${gain.muted ? " is-muted" : ""}">${gain.value}</span>
          ${gain.meta ? `<span class="list-gain-meta">${gain.meta}</span>` : ""}
        </td>
      `;

      row.addEventListener("click", () => {
        navigate(`itemvisu.html?id=${encodeURIComponent(item.id)}`);
      });
      row.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          navigate(`itemvisu.html?id=${encodeURIComponent(item.id)}`);
        }
      });

      els.tbody.appendChild(row);
    });
  }

  function updateEmptyState(hasRows) {
    els.tableWrapper.classList.toggle("hidden", !hasRows);
    els.emptyState.classList.toggle("hidden", hasRows);
  }

  function render() {
    const filteredRows = items.filter(passesFilters);
    const sortedRows = sortRows(filteredRows);

    renderRows(sortedRows);
    updateEmptyState(Boolean(sortedRows.length));
    els.rowCount.textContent = `${formatInteger(sortedRows.length)} résultat${sortedRows.length > 1 ? "s" : ""}`;
    updateSortUi();
  }

  function resetFilters() {
    els.search.value = "";
    els.sector.value = "";
    els.status.value = "";
    els.typeGain.value = "";
    els.dateFrom.value = "";
    els.dateTo.value = "";
    state.sortKey = "dateOuverture";
    state.sortDirection = "desc";
    render();
  }

  initializeFilters();

  [els.search, els.sector, els.status, els.typeGain, els.dateFrom, els.dateTo].forEach((node) => {
    const eventName = node.tagName === "INPUT" && node.type === "search" ? "input" : "change";
    node.addEventListener(eventName, render);
    if (eventName !== "change") {
      node.addEventListener("change", render);
    }
  });

  els.sortButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const clickedKey = button.dataset.sort;

      if (state.sortKey === clickedKey) {
        state.sortDirection = state.sortDirection === "asc" ? "desc" : "asc";
      } else {
        state.sortKey = clickedKey;
        state.sortDirection = clickedKey === "dateOuverture" ? "desc" : "asc";
      }

      render();
    });
  });

  els.reset.addEventListener("click", resetFilters);
  els.emptyReset.addEventListener("click", resetFilters);
  els.newJdi.addEventListener("click", () => {
    navigate("formulaire.html");
  });

  render();
})();
