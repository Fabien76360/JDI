(function () {
  const data = window.JDI_DATA || {};
  const items = Array.isArray(data.items) ? data.items : [];
  const configuredSectors = Array.isArray(data.sectors) ? data.sectors : [];
  const numberFormatter = new Intl.NumberFormat("fr-FR");
  const monthFormatter = new Intl.DateTimeFormat("fr-FR", {
    month: "short",
    year: "2-digit"
  });

  const BASE_GAIN_TYPES = ["Gain de temps", "Économie", "Simplification", "Énergie"];
  const els = {
    kpiTotal: document.getElementById("kpiTotal"),
    kpiDone: document.getElementById("kpiDone"),
    kpiOpen: document.getElementById("kpiOpen"),
    kpiCanceled: document.getElementById("kpiCanceled"),
    sectorBars: document.getElementById("sectorBars"),
    gainTypeBars: document.getElementById("gainTypeBars"),
    monthChart: document.getElementById("monthChart"),
    timelineNote: document.getElementById("timelineNote")
  };

  function formatInteger(value) {
    return numberFormatter.format(Math.round(value || 0));
  }

  function parseIsoDate(isoDate) {
    if (!isoDate) {
      return null;
    }

    const parsed = new Date(`${isoDate}T00:00:00`);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
  }

  function normalizeStatus(rawStatus) {
    if (rawStatus === 1 || rawStatus === "1") return "En cours";
    if (rawStatus === 2 || rawStatus === "2") return "Complété";
    if (rawStatus === 3 || rawStatus === "3") return "Annulé";

    const normalized = (rawStatus || "").toString().normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
    if (normalized === "en cours") return "En cours";
    if (normalized === "complete" || normalized === "complété") return "Complété";
    if (normalized === "annule" || normalized === "annulé") return "Annulé";
    return "En cours";
  }

  function normalizeSector(item) {
    return item.ID_Secteur || item.secteur || "Non renseigné";
  }

  function normalizeGainTypeLabel(rawType) {
    const value = (rawType || "").toString().trim();
    const normalized = value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

    if (!normalized) return "";
    if (normalized === "temps" || normalized === "gain de temps") return "Gain de temps";
    if (normalized === "couts" || normalized === "cout" || normalized === "economie" || normalized === "coûts") return "Économie";
    if (normalized === "energie") return "Énergie";
    if (normalized === "simplification") return "Simplification";

    return value;
  }

  function normalizeGainTypes(item) {
    const rawTypes = item.ID_TypeGains ?? item.typeGain ?? item.typeGains ?? "";

    if (Array.isArray(rawTypes)) {
      return rawTypes.map(normalizeGainTypeLabel).filter(Boolean);
    }

    return rawTypes
      .toString()
      .split(/[,;/|]+/)
      .map((entry) => normalizeGainTypeLabel(entry.trim()))
      .filter(Boolean);
  }

  function buildSectorCounts() {
    const allSectors = Array.from(new Set([
      ...configuredSectors,
      ...items.map(normalizeSector)
    ]));

    return allSectors
      .map((sector) => ({
        label: sector,
        value: items.filter((item) => normalizeSector(item) === sector).length
      }))
      .sort((left, right) => {
        if (right.value !== left.value) return right.value - left.value;
        return left.label.localeCompare(right.label, "fr");
      });
  }

  function buildGainTypeCounts() {
    const detectedTypes = items.flatMap(normalizeGainTypes);
    const allTypes = Array.from(new Set([...BASE_GAIN_TYPES, ...detectedTypes]));

    return allTypes
      .map((type) => ({
        label: type,
        value: items.filter((item) => normalizeGainTypes(item).includes(type)).length
      }))
      .sort((left, right) => {
        if (right.value !== left.value) return right.value - left.value;
        return left.label.localeCompare(right.label, "fr");
      });
  }

  function buildMonthlyCounts() {
    const datedItems = items
      .map((item) => parseIsoDate(item.dateOuverture))
      .filter(Boolean)
      .sort((left, right) => left - right);

    if (!datedItems.length) {
      return [];
    }

    const first = new Date(datedItems[0].getFullYear(), datedItems[0].getMonth(), 1);
    const last = new Date(datedItems[datedItems.length - 1].getFullYear(), datedItems[datedItems.length - 1].getMonth(), 1);
    const months = [];
    let cursor = new Date(first);

    while (cursor <= last) {
      const monthKey = `${cursor.getFullYear()}-${`${cursor.getMonth() + 1}`.padStart(2, "0")}`;
      months.push({
        key: monthKey,
        label: monthFormatter.format(cursor),
        value: items.filter((item) => (item.dateOuverture || "").startsWith(monthKey)).length
      });
      cursor = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1);
    }

    return months.slice(-12);
  }

  function renderKpis() {
    const total = items.length;
    const completed = items.filter((item) => normalizeStatus(item.ID_Statut ?? item.statut) === "Complété").length;
    const open = items.filter((item) => normalizeStatus(item.ID_Statut ?? item.statut) === "En cours").length;
    const canceled = items.filter((item) => normalizeStatus(item.ID_Statut ?? item.statut) === "Annulé").length;

    els.kpiTotal.textContent = formatInteger(total);
    els.kpiDone.textContent = formatInteger(completed);
    els.kpiOpen.textContent = formatInteger(open);
    els.kpiCanceled.textContent = formatInteger(canceled);
  }

  function renderHorizontalBars(container, rows, emptyMessage) {
    container.innerHTML = "";

    if (!rows.length) {
      container.innerHTML = `<div class="info-box">${emptyMessage}</div>`;
      return;
    }

    const maxValue = Math.max(...rows.map((row) => row.value), 1);

    rows.forEach((row) => {
      const line = document.createElement("div");
      line.className = "analyse-v1-bar-row";
      line.innerHTML = `
        <div class="analyse-v1-bar-label">${row.label}</div>
        <div class="analyse-v1-bar-track">
          <span class="analyse-v1-bar-fill" style="width:${Math.round((row.value / maxValue) * 100)}%"></span>
        </div>
        <div class="analyse-v1-bar-value mono">${formatInteger(row.value)}</div>
      `;
      container.appendChild(line);
    });
  }

  function renderMonthChart(rows) {
    els.monthChart.innerHTML = "";

    if (!rows.length) {
      els.timelineNote.textContent = "Aucune date d’ouverture disponible.";
      els.monthChart.innerHTML = "<div class='info-box'>Aucun historique disponible.</div>";
      return;
    }

    const maxValue = Math.max(...rows.map((row) => row.value), 1);
    const recentCount = rows.reduce((sum, row) => sum + row.value, 0);
    els.timelineNote.textContent = `${formatInteger(recentCount)} JDI sur ${rows.length} mois affichés`;

    rows.forEach((row) => {
      const column = document.createElement("div");
      column.className = "analyse-v1-month-col";
      column.innerHTML = `
        <div class="analyse-v1-month-value mono">${formatInteger(row.value)}</div>
        <div class="analyse-v1-month-bar-wrap">
          <span class="analyse-v1-month-bar" style="height:${Math.max(6, Math.round((row.value / maxValue) * 100))}%"></span>
        </div>
        <div class="analyse-v1-month-label">${row.label}</div>
      `;
      els.monthChart.appendChild(column);
    });
  }

  renderKpis();
  renderHorizontalBars(els.sectorBars, buildSectorCounts(), "Aucun secteur à afficher.");
  renderHorizontalBars(els.gainTypeBars, buildGainTypeCounts(), "Aucun type de gain à afficher.");
  renderMonthChart(buildMonthlyCounts());
})();
