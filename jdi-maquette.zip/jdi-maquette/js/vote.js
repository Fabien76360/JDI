(function () {
  const ACCESS_KEY = "jdi_month_vote_access_v1";
  const STATE_KEY = "jdi_month_cycle_state_v1";
  const data = window.JDI_DATA || {};
  const common = window.JDI_COMMON || {};
  const items = Array.isArray(data.items) ? data.items : [];
  const baseState = data.jdiMonth || data.vote || {};
  const navigate = typeof common.navigate === "function" ? common.navigate : (url) => {
    window.location.href = url;
  };
  const formatDate = typeof common.formatDate === "function" ? common.formatDate : (value) => value || "-";
  const getQueryParam = typeof common.getQueryParam === "function" ? common.getQueryParam : () => "";
  const users = Array.isArray(data.users) && data.users.length ? data.users : ["fabien.genet"];

  const els = {
    tabButtons: Array.from(document.querySelectorAll(".vote-tab-button")),
    tabPanels: Array.from(document.querySelectorAll(".vote-tab-panel")),
    candidateCycleSelect: document.getElementById("candidateCycleSelect"),
    candidateCycleMeta: document.getElementById("candidateCycleMeta"),
    candidateEligibleSummary: document.getElementById("candidateEligibleSummary"),
    candidateEligibleList: document.getElementById("candidateEligibleList"),
    candidateSelectedList: document.getElementById("candidateSelectedList"),
    voteAccessBox: document.getElementById("voteAccessBox"),
    voteWorkspace: document.getElementById("voteWorkspace"),
    votePassword: document.getElementById("votePassword"),
    voteLoginBtn: document.getElementById("voteLoginBtn"),
    voteAccessMsg: document.getElementById("voteAccessMsg"),
    voteCycleSelect: document.getElementById("voteCycleSelect"),
    voteCycleMeta: document.getElementById("voteCycleMeta"),
    voteUserSelect: document.getElementById("voteUserSelect"),
    voteLogoutBtn: document.getElementById("voteLogoutBtn"),
    voteStatusBanner: document.getElementById("voteStatusBanner"),
    voteCandidateList: document.getElementById("voteCandidateList"),
    palmaresWinnerList: document.getElementById("palmaresWinnerList"),
    palmaresYearSelect: document.getElementById("palmaresYearSelect"),
    annualCandidateList: document.getElementById("annualCandidateList"),
    currentUser: document.getElementById("currentUser")
  };

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function getSeedState() {
    return {
      password: baseState.password || "JDI2026",
      cycles: Array.isArray(baseState.cycles) ? clone(baseState.cycles) : [],
      candidates: Array.isArray(baseState.candidates) ? clone(baseState.candidates) : [],
      votes: Array.isArray(baseState.votes) ? clone(baseState.votes) : []
    };
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STATE_KEY);
      if (!raw) {
        return getSeedState();
      }

      const parsed = JSON.parse(raw);
      if (!parsed || !Array.isArray(parsed.cycles) || !Array.isArray(parsed.candidates) || !Array.isArray(parsed.votes)) {
        return getSeedState();
      }

      return {
        password: parsed.password || baseState.password || "JDI2026",
        cycles: parsed.cycles,
        candidates: parsed.candidates,
        votes: parsed.votes
      };
    } catch (error) {
      return getSeedState();
    }
  }

  let state = loadState();
  let activeTab = getQueryParam("tab") || "candidates";

  const currentUser = (() => {
    const footerText = (els.currentUser && els.currentUser.textContent) || "";
    const fromFooter = footerText.includes(":") ? footerText.split(":").slice(1).join(":").trim() : "";
    return fromFooter || users[0] || "utilisateur";
  })();

  function saveState() {
    localStorage.setItem(STATE_KEY, JSON.stringify(state));
  }

  function getTodayIso() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  function parseIsoDate(iso) {
    if (!iso || !/^\d{4}-\d{2}-\d{2}$/.test(iso)) {
      return null;
    }

    const [year, month, day] = iso.split("-").map(Number);
    return new Date(year, month - 1, day);
  }

  function isDatePast(iso) {
    const target = parseIsoDate(iso);
    if (!target) {
      return false;
    }

    const today = parseIsoDate(getTodayIso());
    return Boolean(today && today > target);
  }

  function padMonth(month) {
    return String(month).padStart(2, "0");
  }

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function slugify(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");
  }

  function getCycleById(cycleId) {
    return state.cycles.find((cycle) => cycle.id_cycle === cycleId) || null;
  }

  function getItemById(itemId) {
    return items.find((item) => item.id === itemId) || null;
  }

  function getCycleCandidates(cycleId) {
    return state.candidates.filter((candidate) => {
      return candidate.id_cycle === cycleId && candidate.is_active !== false;
    });
  }

  function getCycleVotes(cycleId) {
    return state.votes.filter((vote) => vote.id_cycle === cycleId);
  }

  function getCandidateById(candidateId) {
    return state.candidates.find((candidate) => candidate.id_candidate === candidateId) || null;
  }

  function getCandidateForJdi(cycleId, jdiId) {
    return getCycleCandidates(cycleId).find((candidate) => candidate.id_jdi === jdiId) || null;
  }

  function getCandidateForSector(cycleId, sectorId) {
    return getCycleCandidates(cycleId).find((candidate) => candidate.id_secteur === sectorId) || null;
  }

  function getVoteForUser(cycleId, voterIdentifier) {
    return state.votes.find((vote) => {
      return vote.id_cycle === cycleId && vote.voter_identifier === voterIdentifier;
    }) || null;
  }

  function getItemStatus(item) {
    return item && item.statut ? item.statut : "";
  }

  function getItemSector(item) {
    return item && (item.secteur || item.id_secteur) ? (item.secteur || item.id_secteur) : "Secteur non renseigné";
  }

  function getItemTitle(item) {
    return item ? (item.libelle || item.titre || item.numero || item.id) : "JDI non trouvé";
  }

  function getItemTypeGain(item) {
    return item ? (item.typeGain || item.typeGains || "Type de gain non renseigné") : "Type de gain non renseigné";
  }

  function getItemReferenceDate(item) {
    if (!item) {
      return "";
    }

    return item.dateCloture || item.dateOuverture || "";
  }

  function getGainDisplay(item) {
    if (!item) {
      return { value: "Gain non renseigné", muted: true };
    }

    const gainQuantifie = String(item.gainQuantifie || "").trim();
    if (gainQuantifie && gainQuantifie !== "N/A") {
      return { value: gainQuantifie.replace("EUR", "€"), muted: false };
    }

    if (item.gainMode === "aucun") {
      return { value: "Gain non renseigné", muted: true };
    }

    const fragments = [];
    const gainTempsHeures = Number(item.gainTempsHeures || 0);
    const gainEuro = Number(item.gainEuro || 0);

    if (Number.isFinite(gainTempsHeures) && gainTempsHeures > 0) {
      fragments.push(`${Math.round(gainTempsHeures)} h`);
    }

    if (Number.isFinite(gainEuro) && gainEuro > 0) {
      fragments.push(`${Math.round(gainEuro)} €`);
    }

    if (!fragments.length) {
      return { value: "Gain à consolider", muted: true };
    }

    return { value: fragments.join(" / "), muted: false };
  }

  function getCycleMonthKey(year, month) {
    return `${year}-${padMonth(month)}`;
  }

  function getPreviousMonthKey(year, month) {
    const previousMonth = month === 1 ? 12 : month - 1;
    const previousYear = month === 1 ? year - 1 : year;
    return getCycleMonthKey(previousYear, previousMonth);
  }

  function isItemEligibleForCycle(item, cycle) {
    if (!item || !cycle) {
      return false;
    }

    if (getItemStatus(item) !== "Complété") {
      return false;
    }

    const referenceDate = getItemReferenceDate(item);
    if (!referenceDate) {
      return false;
    }

    const monthKey = referenceDate.slice(0, 7);
    const currentCycleKey = getCycleMonthKey(cycle.year, cycle.month);
    const previousCycleKey = getPreviousMonthKey(cycle.year, cycle.month);

    return monthKey === currentCycleKey || monthKey === previousCycleKey;
  }

  function isCandidacyOpen(cycle) {
    if (!cycle) {
      return false;
    }

    if (cycle.status !== "candidacy") {
      return false;
    }

    return !cycle.candidacy_close_date || !isDatePast(cycle.candidacy_close_date);
  }

  function isVoteOpen(cycle) {
    if (!cycle) {
      return false;
    }

    if (cycle.status !== "vote") {
      return false;
    }

    return !cycle.vote_close_date || !isDatePast(cycle.vote_close_date);
  }

  function getCycleStatusMeta(cycle) {
    if (!cycle) {
      return { label: "Non configuré", className: "" };
    }

    if (cycle.status === "candidacy") {
      return { label: "Candidatures ouvertes", className: "status-candidacy" };
    }

    if (cycle.status === "vote") {
      return { label: "Vote ouvert", className: "status-vote" };
    }

    if (cycle.status === "closed") {
      return { label: "Cycle clôturé", className: "status-closed" };
    }

    return { label: "Cycle planifié", className: "status-planned" };
  }

  function summarizeCycle(cycle) {
    const candidates = getCycleCandidates(cycle.id_cycle);
    const votes = getCycleVotes(cycle.id_cycle);
    const counts = {};

    candidates.forEach((candidate) => {
      counts[candidate.id_candidate] = 0;
    });

    votes.forEach((vote) => {
      if (counts[vote.id_candidate] === undefined) {
        return;
      }

      counts[vote.id_candidate] += 1;
    });

    let leadingCandidateId = "";
    let topCount = -1;
    let isTie = false;

    Object.keys(counts).forEach((candidateId) => {
      const count = counts[candidateId];

      if (count > topCount) {
        leadingCandidateId = candidateId;
        topCount = count;
        isTie = false;
        return;
      }

      if (count === topCount && count > 0) {
        isTie = true;
      }
    });

    let winnerJdiId = (cycle.winner_jdi_id || "").trim();

    if (!winnerJdiId && cycle.status === "closed" && leadingCandidateId && !isTie && topCount > 0) {
      const winnerCandidate = getCandidateById(leadingCandidateId);
      winnerJdiId = winnerCandidate ? winnerCandidate.id_jdi : "";
    }

    return {
      candidates,
      votes,
      counts,
      topCount: Math.max(topCount, 0),
      leadingCandidateId,
      winnerJdiId,
      isTie
    };
  }

  function getWinnerCycles() {
    return state.cycles
      .map((cycle) => {
        return {
          cycle,
          summary: summarizeCycle(cycle)
        };
      })
      .filter((entry) => entry.summary.winnerJdiId)
      .sort((left, right) => {
        return `${right.cycle.year}-${padMonth(right.cycle.month)}`.localeCompare(`${left.cycle.year}-${padMonth(left.cycle.month)}`);
      });
  }

  function createEmptyState(message, actionLabel, actionTarget) {
    const actionButton = actionLabel && actionTarget
      ? `<button class="btn secondary month-empty-action" type="button" data-empty-target="${escapeHtml(actionTarget)}">${escapeHtml(actionLabel)}</button>`
      : "";

    return `
      <div class="month-empty-state">
        <p>${escapeHtml(message)}</p>
        ${actionButton}
      </div>
    `;
  }

  function renderCycleMeta(cycle) {
    if (!cycle) {
      return createEmptyState("Aucun cycle mensuel n'est configuré.", "", "");
    }

    const status = getCycleStatusMeta(cycle);

    return `
      <div class="month-cycle-meta-head">
        <span class="month-status-badge ${status.className}">${escapeHtml(status.label)}</span>
        <span class="month-cycle-label">${escapeHtml(cycle.label)}</span>
      </div>
      <p class="month-cycle-text">Candidatures: ${escapeHtml(formatDate(cycle.candidacy_open_date))} au ${escapeHtml(formatDate(cycle.candidacy_close_date))}</p>
      <p class="month-cycle-text">Vote: ${escapeHtml(formatDate(cycle.vote_open_date))} au ${escapeHtml(formatDate(cycle.vote_close_date))}</p>
    `;
  }

  function renderCycleOptions(selectNode, preferredCycleId) {
    if (!selectNode) {
      return;
    }

    selectNode.innerHTML = "";

    state.cycles.forEach((cycle) => {
      const option = document.createElement("option");
      option.value = cycle.id_cycle;
      option.textContent = cycle.label;
      selectNode.appendChild(option);
    });

    if (!state.cycles.length) {
      return;
    }

    const targetCycleId = state.cycles.some((cycle) => cycle.id_cycle === preferredCycleId)
      ? preferredCycleId
      : state.cycles[0].id_cycle;

    selectNode.value = targetCycleId;
  }

  function getDefaultCycleIdByStatus(preferredStatuses) {
    const match = state.cycles.find((cycle) => preferredStatuses.includes(cycle.status));
    if (match) {
      return match.id_cycle;
    }

    return state.cycles[0] ? state.cycles[0].id_cycle : "";
  }

  function getSelectedCandidateCycle() {
    return getCycleById(els.candidateCycleSelect.value);
  }

  function getSelectedVoteCycle() {
    return getCycleById(els.voteCycleSelect.value);
  }

  function getSelectedPalmaresYear() {
    return Number(els.palmaresYearSelect.value || 0);
  }

  function renderCandidateTab() {
    const cycle = getSelectedCandidateCycle();
    els.candidateCycleMeta.innerHTML = renderCycleMeta(cycle);

    if (!cycle) {
      els.candidateEligibleList.innerHTML = createEmptyState("Aucun cycle disponible pour les candidatures.", "", "");
      els.candidateSelectedList.innerHTML = createEmptyState("Aucune candidature à afficher.", "", "");
      els.candidateEligibleSummary.textContent = "";
      return;
    }

    const cycleCandidates = getCycleCandidates(cycle.id_cycle);
    const candidatesBySector = {};

    cycleCandidates.forEach((candidate) => {
      candidatesBySector[candidate.id_secteur] = candidate;
    });

    const eligibleItems = items
      .filter((item) => isItemEligibleForCycle(item, cycle))
      .sort((left, right) => getItemReferenceDate(right).localeCompare(getItemReferenceDate(left)));

    els.candidateEligibleSummary.textContent = eligibleItems.length
      ? `${eligibleItems.length} JDI potentiellement mobilisables`
      : "Aucun JDI éligible pour ce cycle";

    if (!eligibleItems.length) {
      els.candidateEligibleList.innerHTML = createEmptyState("Aucun JDI complété ne correspond à la période utile de ce cycle.", "", "");
    } else {
      els.candidateEligibleList.innerHTML = eligibleItems.map((item) => {
        const gain = getGainDisplay(item);
        const sector = getItemSector(item);
        const sectorCandidate = candidatesBySector[sector];
        const existingCandidate = getCandidateForJdi(cycle.id_cycle, item.id);
        const candidacyOpen = isCandidacyOpen(cycle);
        let actionLabel = "Proposer comme candidat";
        let actionDisabled = "";
        let helperText = "";

        if (!candidacyOpen) {
          actionLabel = "Candidatures closes";
          actionDisabled = "disabled";
          helperText = "Le cycle n'accepte plus de nouvelles propositions.";
        } else if (existingCandidate) {
          actionLabel = "Déjà proposé";
          actionDisabled = "disabled";
          helperText = "Ce JDI est déjà enregistré comme candidat pour ce cycle.";
        } else if (sectorCandidate) {
          actionLabel = "Secteur déjà représenté";
          actionDisabled = "disabled";
          helperText = "Un seul JDI par service est autorisé sur un cycle mensuel.";
        }

        return `
          <article class="month-item-card">
            <div class="month-item-head">
              <div>
                <p class="month-item-meta mono">${escapeHtml(item.numero || item.id)}</p>
                <h3 class="month-item-title">${escapeHtml(getItemTitle(item))}</h3>
              </div>
              <span class="month-sector-chip">${escapeHtml(sector)}</span>
            </div>
            <div class="month-item-grid">
              <div class="month-item-info">
                <p><strong>Date</strong><span>${escapeHtml(formatDate(getItemReferenceDate(item)))}</span></p>
                <p><strong>Type de gain</strong><span>${escapeHtml(getItemTypeGain(item))}</span></p>
                <p><strong>Gain</strong><span class="${gain.muted ? "is-muted" : ""}">${escapeHtml(gain.value)}</span></p>
              </div>
              <div class="month-media-strip">
                ${renderMediaPreview(item.imageAvant, "Avant")}
                ${renderMediaPreview(item.imageApres, "Après")}
              </div>
            </div>
            ${helperText ? `<p class="month-helper-text">${escapeHtml(helperText)}</p>` : ""}
            <div class="month-card-actions">
              <a class="btn secondary" href="itemvisu.html?id=${encodeURIComponent(item.id)}">Voir le JDI</a>
              <button class="btn primary" type="button" data-action="propose-candidate" data-jdi-id="${escapeHtml(item.id)}" ${actionDisabled}>${escapeHtml(actionLabel)}</button>
            </div>
          </article>
        `;
      }).join("");
    }

    if (!cycleCandidates.length) {
      els.candidateSelectedList.innerHTML = createEmptyState("Aucun candidat n'a encore été proposé pour ce cycle.", "", "");
      return;
    }

    const sortedCandidates = cycleCandidates
      .map((candidate) => ({ candidate, item: getItemById(candidate.id_jdi) }))
      .filter((entry) => entry.item)
      .sort((left, right) => getItemReferenceDate(right.item).localeCompare(getItemReferenceDate(left.item)));

    els.candidateSelectedList.innerHTML = sortedCandidates.map((entry) => {
      const item = entry.item;
      const gain = getGainDisplay(item);

      return `
        <article class="month-item-card is-selected">
          <div class="month-item-head">
            <div>
              <p class="month-item-meta mono">${escapeHtml(item.numero || item.id)}</p>
              <h3 class="month-item-title">${escapeHtml(getItemTitle(item))}</h3>
            </div>
            <span class="month-sector-chip">${escapeHtml(getItemSector(item))}</span>
          </div>
          <div class="month-item-grid">
            <div class="month-item-info">
              <p><strong>Date</strong><span>${escapeHtml(formatDate(getItemReferenceDate(item)))}</span></p>
              <p><strong>Type de gain</strong><span>${escapeHtml(getItemTypeGain(item))}</span></p>
              <p><strong>Gain</strong><span class="${gain.muted ? "is-muted" : ""}">${escapeHtml(gain.value)}</span></p>
              <p><strong>Proposé par</strong><span>${escapeHtml(entry.candidate.proposed_by_user || "-")}</span></p>
            </div>
            <div class="month-media-strip">
              ${renderMediaPreview(item.imageAvant, "Avant")}
              ${renderMediaPreview(item.imageApres, "Après")}
            </div>
          </div>
          <div class="month-card-actions">
            <a class="btn secondary" href="itemvisu.html?id=${encodeURIComponent(item.id)}">Voir le JDI</a>
          </div>
        </article>
      `;
    }).join("");
  }

  function renderMediaPreview(source, label) {
    if (!source) {
      return `<div class="month-media-fallback">${escapeHtml(label)} indisponible</div>`;
    }

    return `<img class="month-media-thumb" src="${escapeHtml(source)}" alt="${escapeHtml(label)}">`;
  }

  function renderVoteGate() {
    const authorized = sessionStorage.getItem(ACCESS_KEY) === "1";
    els.voteAccessBox.classList.toggle("hidden", authorized);
    els.voteWorkspace.classList.toggle("hidden", !authorized);
  }

  function renderVoteTab() {
    renderVoteGate();

    if (els.voteUserSelect.options.length === 0) {
      els.voteUserSelect.innerHTML = users.map((user) => {
        return `<option value="${escapeHtml(user)}">${escapeHtml(user)}</option>`;
      }).join("");
    }

    const cycle = getSelectedVoteCycle();
    els.voteCycleMeta.innerHTML = renderCycleMeta(cycle);

    if (!cycle) {
      els.voteStatusBanner.innerHTML = createEmptyState("Aucun cycle disponible pour le vote.", "", "");
      els.voteCandidateList.innerHTML = "";
      return;
    }

    const summary = summarizeCycle(cycle);
    const currentVoter = els.voteUserSelect.value || users[0];
    const currentVote = getVoteForUser(cycle.id_cycle, currentVoter);
    const voteOpen = isVoteOpen(cycle);

    if (cycle.status === "closed") {
      if (summary.winnerJdiId) {
        const winnerItem = getItemById(summary.winnerJdiId);
        els.voteStatusBanner.innerHTML = `<strong>Cycle clôturé.</strong> Lauréat: ${escapeHtml(getItemTitle(winnerItem))}.`;
      } else {
        els.voteStatusBanner.innerHTML = "<strong>Cycle clôturé.</strong> Le gagnant reste à confirmer.";
      }
    } else if (voteOpen) {
      const currentVoteItem = currentVote ? getItemById((getCandidateById(currentVote.id_candidate) || {}).id_jdi) : null;
      els.voteStatusBanner.innerHTML = currentVoteItem
        ? `<strong>Vote ouvert.</strong> Votre vote actuel porte sur ${escapeHtml(getItemTitle(currentVoteItem))}.`
        : "<strong>Vote ouvert.</strong> Une justification est obligatoire pour valider ou modifier votre choix.";
    } else {
      els.voteStatusBanner.innerHTML = "<strong>Vote non disponible.</strong> Le cycle sélectionné n'est pas ouvert au vote.";
    }

    if (!summary.candidates.length) {
      els.voteCandidateList.innerHTML = createEmptyState("Aucun candidat n'est disponible pour ce cycle.", "", "");
      return;
    }

    els.voteCandidateList.innerHTML = summary.candidates.map((candidate) => {
      const item = getItemById(candidate.id_jdi);
      if (!item) {
        return "";
      }

      const gain = getGainDisplay(item);
      const currentVoteForCard = currentVote && currentVote.id_candidate === candidate.id_candidate;
      const textareaValue = currentVoteForCard ? currentVote.justification_text || "" : "";
      const helper = currentVoteForCard
        ? "Votre vote actuel. Vous pouvez encore le modifier tant que le vote est ouvert."
        : "Pourquoi ce JDI mérite d'être élu ?";
      const buttonLabel = currentVoteForCard ? "Mettre à jour mon vote" : "Valider mon vote";
      const disabledAttr = voteOpen ? "" : "disabled";
      const count = summary.counts[candidate.id_candidate] || 0;
      const isLeader = summary.leadingCandidateId === candidate.id_candidate && count > 0;

      return `
        <article class="month-item-card vote-candidate-card ${currentVoteForCard ? "is-current-vote" : ""}">
          <div class="month-item-head">
            <div>
              <p class="month-item-meta mono">${escapeHtml(item.numero || item.id)}</p>
              <h3 class="month-item-title">${escapeHtml(getItemTitle(item))}</h3>
            </div>
            <div class="month-head-side">
              <span class="month-sector-chip">${escapeHtml(getItemSector(item))}</span>
              ${isLeader ? "<span class=\"month-leading-chip\">En tête</span>" : ""}
            </div>
          </div>
          <div class="month-item-grid">
            <div class="month-item-info">
              <p><strong>Type de gain</strong><span>${escapeHtml(getItemTypeGain(item))}</span></p>
              <p><strong>Gain</strong><span class="${gain.muted ? "is-muted" : ""}">${escapeHtml(gain.value)}</span></p>
              <p><strong>Date</strong><span>${escapeHtml(formatDate(getItemReferenceDate(item)))}</span></p>
              <p><strong>Votes valides</strong><span>${escapeHtml(String(count))}</span></p>
            </div>
            <div class="month-media-strip">
              ${renderMediaPreview(item.imageAvant, "Avant")}
              ${renderMediaPreview(item.imageApres, "Après")}
            </div>
          </div>
          <div class="month-card-actions month-card-actions-split">
            <a class="btn secondary" href="itemvisu.html?id=${encodeURIComponent(item.id)}">Voir le JDI</a>
          </div>
          <div class="month-vote-form">
            <label for="voteJustification-${escapeHtml(candidate.id_candidate)}">Je recommande ce JDI</label>
            <textarea id="voteJustification-${escapeHtml(candidate.id_candidate)}" class="month-vote-textarea" data-candidate-id="${escapeHtml(candidate.id_candidate)}" placeholder="impact concret, idée simple et efficace, amélioration facilement reproductible, fort bénéfice terrain" ${disabledAttr}>${escapeHtml(textareaValue)}</textarea>
            <p class="month-helper-text">${escapeHtml(helper)}</p>
            <button class="btn primary month-vote-submit" type="button" data-action="submit-vote" data-candidate-id="${escapeHtml(candidate.id_candidate)}" ${disabledAttr}>${escapeHtml(buttonLabel)}</button>
          </div>
        </article>
      `;
    }).join("");
  }

  function renderPalmaresTab() {
    const winnerCycles = getWinnerCycles();
    const years = Array.from(new Set(winnerCycles.map((entry) => entry.cycle.year))).sort((left, right) => right - left);

    els.palmaresYearSelect.innerHTML = years.map((year) => {
      return `<option value="${year}">${year}</option>`;
    }).join("");

    if (years.length && !years.includes(getSelectedPalmaresYear())) {
      els.palmaresYearSelect.value = String(years[0]);
    }

    if (!winnerCycles.length) {
      els.palmaresWinnerList.innerHTML = createEmptyState("Aucun gagnant mensuel n'est encore archivé.", "", "");
      els.annualCandidateList.innerHTML = createEmptyState("Aucun candidat annuel disponible pour le moment.", "", "");
      return;
    }

    els.palmaresWinnerList.innerHTML = winnerCycles.map((entry) => {
      const winnerItem = getItemById(entry.summary.winnerJdiId);
      if (!winnerItem) {
        return "";
      }

      const gain = getGainDisplay(winnerItem);

      return `
        <article class="month-item-card is-winner-card">
          <div class="month-item-head">
            <div>
              <p class="month-item-meta">${escapeHtml(entry.cycle.label)}</p>
              <h3 class="month-item-title">${escapeHtml(getItemTitle(winnerItem))}</h3>
            </div>
            <span class="month-winner-badge">Lauréat</span>
          </div>
          <div class="month-item-grid">
            <div class="month-item-info">
              <p><strong>Secteur</strong><span>${escapeHtml(getItemSector(winnerItem))}</span></p>
              <p><strong>Gain</strong><span class="${gain.muted ? "is-muted" : ""}">${escapeHtml(gain.value)}</span></p>
              <p><strong>Type de gain</strong><span>${escapeHtml(getItemTypeGain(winnerItem))}</span></p>
            </div>
            <div class="month-media-strip">
              ${renderMediaPreview(winnerItem.imageAvant, "Avant")}
              ${renderMediaPreview(winnerItem.imageApres, "Après")}
            </div>
          </div>
          <div class="month-card-actions">
            <a class="btn secondary" href="itemvisu.html?id=${encodeURIComponent(winnerItem.id)}">Voir le JDI</a>
            <a class="btn primary" href="itemvisu.html?id=${encodeURIComponent(winnerItem.id)}&view=poster">Voir l'affiche</a>
          </div>
        </article>
      `;
    }).join("");

    const selectedYear = getSelectedPalmaresYear() || years[0];
    const yearEntries = winnerCycles.filter((entry) => entry.cycle.year === selectedYear);

    if (!yearEntries.length) {
      els.annualCandidateList.innerHTML = createEmptyState("Aucun gagnant mensuel enregistré sur cette année.", "", "");
      return;
    }

    els.annualCandidateList.innerHTML = yearEntries.map((entry) => {
      const winnerItem = getItemById(entry.summary.winnerJdiId);
      const gain = getGainDisplay(winnerItem);

      return `
        <article class="month-year-row">
          <div>
            <p class="month-year-label">${escapeHtml(entry.cycle.label)}</p>
            <h3 class="month-year-title">${escapeHtml(getItemTitle(winnerItem))}</h3>
          </div>
          <div class="month-year-meta">
            <span>${escapeHtml(getItemSector(winnerItem))}</span>
            <span class="${gain.muted ? "is-muted" : ""}">${escapeHtml(gain.value)}</span>
          </div>
        </article>
      `;
    }).join("");
  }

  function setActiveTab(tabName) {
    activeTab = tabName;

    els.tabButtons.forEach((button) => {
      const isActive = button.dataset.tab === tabName;
      button.classList.toggle("is-active", isActive);
      button.setAttribute("aria-selected", String(isActive));
    });

    els.tabPanels.forEach((panel) => {
      panel.hidden = panel.dataset.panel !== tabName;
    });
  }

  function handleCandidateProposal(jdiId) {
    const cycle = getSelectedCandidateCycle();
    const item = getItemById(jdiId);

    if (!cycle || !item) {
      return;
    }

    if (!isCandidacyOpen(cycle)) {
      window.alert("Les candidatures sont closes pour ce cycle.");
      return;
    }

    if (getItemStatus(item) !== "Complété") {
      window.alert("Seuls les JDI au statut Complété peuvent être proposés.");
      return;
    }

    if (getCandidateForJdi(cycle.id_cycle, item.id)) {
      window.alert("Ce JDI est déjà candidat pour le cycle sélectionné.");
      return;
    }

    const sectorId = getItemSector(item);
    if (getCandidateForSector(cycle.id_cycle, sectorId)) {
      window.alert("Ce secteur a déjà proposé un candidat pour ce cycle.");
      return;
    }

    state.candidates.push({
      id_candidate: `cand-${cycle.id_cycle}-${slugify(sectorId)}`,
      id_cycle: cycle.id_cycle,
      id_jdi: item.id,
      id_secteur: sectorId,
      proposed_by_user: currentUser,
      proposed_at: getTodayIso(),
      is_active: true
    });

    saveState();
    renderCandidateTab();
    renderVoteTab();
    renderPalmaresTab();
  }

  function handleVoteSubmit(candidateId) {
    const cycle = getSelectedVoteCycle();
    const candidate = getCandidateById(candidateId);
    const voterIdentifier = els.voteUserSelect.value || users[0];

    if (!cycle || !candidate) {
      return;
    }

    if (!isVoteOpen(cycle)) {
      window.alert("Le vote n'est pas ouvert sur ce cycle.");
      return;
    }

    const textarea = els.voteCandidateList.querySelector(`[data-candidate-id="${candidateId}"].month-vote-textarea`);
    const justification = textarea ? textarea.value.trim() : "";

    if (!justification) {
      window.alert("La justification est obligatoire.");
      return;
    }

    const nowIso = getTodayIso();
    const existingVoteIndex = state.votes.findIndex((vote) => {
      return vote.id_cycle === cycle.id_cycle && vote.voter_identifier === voterIdentifier;
    });
    const payload = {
      id_vote: `vote-${cycle.id_cycle}-${slugify(voterIdentifier)}`,
      id_cycle: cycle.id_cycle,
      id_candidate: candidate.id_candidate,
      voter_identifier: voterIdentifier,
      justification_text: justification,
      created_at: existingVoteIndex >= 0 ? state.votes[existingVoteIndex].created_at : nowIso,
      updated_at: nowIso
    };

    if (existingVoteIndex >= 0) {
      state.votes[existingVoteIndex] = payload;
    } else {
      state.votes.push(payload);
    }

    saveState();
    renderVoteTab();
    renderPalmaresTab();
  }

  function bindEvents() {
    els.tabButtons.forEach((button) => {
      button.addEventListener("click", () => {
        setActiveTab(button.dataset.tab);
      });
    });

    els.candidateCycleSelect.addEventListener("change", renderCandidateTab);
    els.voteCycleSelect.addEventListener("change", renderVoteTab);
    els.voteUserSelect.addEventListener("change", renderVoteTab);
    els.palmaresYearSelect.addEventListener("change", renderPalmaresTab);

    els.voteLoginBtn.addEventListener("click", () => {
      if (els.votePassword.value === state.password) {
        sessionStorage.setItem(ACCESS_KEY, "1");
        els.voteAccessMsg.textContent = "";
        renderVoteTab();
        return;
      }

      els.voteAccessMsg.textContent = "Mot de passe incorrect.";
    });

    els.voteLogoutBtn.addEventListener("click", () => {
      sessionStorage.removeItem(ACCESS_KEY);
      els.votePassword.value = "";
      renderVoteTab();
    });

    els.candidateEligibleList.addEventListener("click", (event) => {
      const actionButton = event.target.closest("[data-action='propose-candidate']");
      if (!actionButton) {
        return;
      }

      handleCandidateProposal(actionButton.dataset.jdiId);
    });

    els.voteCandidateList.addEventListener("click", (event) => {
      const actionButton = event.target.closest("[data-action='submit-vote']");
      if (!actionButton) {
        return;
      }

      handleVoteSubmit(actionButton.dataset.candidateId);
    });

    document.addEventListener("click", (event) => {
      const actionButton = event.target.closest("[data-empty-target]");
      if (!actionButton) {
        return;
      }

      setActiveTab(actionButton.dataset.emptyTarget);
    });
  }

  function bootstrapSelections() {
    renderCycleOptions(els.candidateCycleSelect, getDefaultCycleIdByStatus(["candidacy", "vote", "closed", "planned"]));
    renderCycleOptions(els.voteCycleSelect, getDefaultCycleIdByStatus(["vote", "closed", "candidacy", "planned"]));
    els.voteUserSelect.innerHTML = users.map((user) => {
      return `<option value="${escapeHtml(user)}">${escapeHtml(user)}</option>`;
    }).join("");

    const palmaresYears = Array.from(new Set(state.cycles.map((cycle) => cycle.year))).sort((left, right) => right - left);
    els.palmaresYearSelect.innerHTML = palmaresYears.map((year) => {
      return `<option value="${year}">${year}</option>`;
    }).join("");
  }

  function render() {
    bootstrapSelections();
    setActiveTab(["candidates", "vote", "palmares"].includes(activeTab) ? activeTab : "candidates");
    renderCandidateTab();
    renderVoteTab();
    renderPalmaresTab();
  }

  bindEvents();
  render();
})();
