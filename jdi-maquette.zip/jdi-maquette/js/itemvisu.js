(function () {
  const data = window.JDI_DATA || {};
  const common = window.JDI_COMMON || {};
  const items = Array.isArray(data.items) ? data.items : [];
  const getQueryParam = typeof common.getQueryParam === "function" ? common.getQueryParam : () => "";
  const formatDate = typeof common.formatDate === "function" ? common.formatDate : (value) => value || "-";
  const statusMeta = typeof common.statusMeta === "function"
    ? common.statusMeta
    : (status) => ({ label: status || "-", className: "" });
  const navigate = typeof common.navigate === "function"
    ? common.navigate
    : (url) => { window.location.href = url; };

  const itemId = getQueryParam("id") || (items[0] && items[0].id);
  const item = items.find((entry) => entry.id === itemId) || items[0];

  if (!item) {
    return;
  }

  const els = {
    headerMeta: document.getElementById("itemHeaderMeta"),
    sheetNumber: document.getElementById("sheetNumber"),
    sheetTitle: document.getElementById("sheetTitle"),
    metaSecteur: document.getElementById("metaSecteur"),
    metaStatus: document.getElementById("metaStatus"),
    metaDateOuverture: document.getElementById("metaDateOuverture"),
    metaDateCloture: document.getElementById("metaDateCloture"),
    txtAvant: document.getElementById("txtAvant"),
    txtApres: document.getElementById("txtApres"),
    txtConditions: document.getElementById("txtConditions"),
    txtContributeurs: document.getElementById("txtContributeurs"),
    txtGains: document.getElementById("txtGains"),
    imgAvant: document.getElementById("imgAvant"),
    imgApres: document.getElementById("imgApres"),
    imgAvantFallback: document.getElementById("imgAvantFallback"),
    imgApresFallback: document.getElementById("imgApresFallback"),
    posterNumber: document.getElementById("posterNumber"),
    posterTitle: document.getElementById("posterTitle"),
    posterBeforeText: document.getElementById("posterBeforeText"),
    posterAfterText: document.getElementById("posterAfterText"),
    posterImgAvant: document.getElementById("posterImgAvant"),
    posterImgApres: document.getElementById("posterImgApres"),
    posterImgAvantFallback: document.getElementById("posterImgAvantFallback"),
    posterImgApresFallback: document.getElementById("posterImgApresFallback"),
    posterGainValue: document.getElementById("posterGainValue"),
    posterTypeBadges: document.getElementById("posterTypeBadges"),
    posterContributors: document.getElementById("posterContributors"),
    posterSecteur: document.getElementById("posterSecteur"),
    posterDateCloture: document.getElementById("posterDateCloture"),
    posterLockedNote: document.getElementById("posterLockedNote"),
    posterToggleBtn: document.getElementById("posterToggleBtn"),
    printPosterBtn: document.getElementById("printPosterBtn"),
    backBtn: document.getElementById("backBtn"),
    editBtn: document.getElementById("editBtn")
  };

  const isCompleted = item.statut === "Complété";
  const initialPosterMode = getQueryParam("view") === "poster" && isCompleted;
  const currencyFormatter = new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 0
  });
  const numberFormatter = new Intl.NumberFormat("fr-FR");

  function formatInteger(value) {
    return numberFormatter.format(Math.round(value || 0));
  }

  function getTitle() {
    return item.libelle || item.titre || item.numero || item.id;
  }

  function getText(value, fallback) {
    const text = (value || "").toString().trim();
    return text || fallback;
  }

  function getContributorsText() {
    return getText(item.contributeurs, "Contribution non renseignée");
  }

  function getGainDisplay() {
    const gainQuantifie = (item.gainQuantifie || "").toString().trim();

    if (gainQuantifie && gainQuantifie !== "N/A") {
      return {
        value: gainQuantifie.replace("EUR", "€"),
        muted: false
      };
    }

    if (item.gainMode === "aucun") {
      return {
        value: "Gain non renseigné",
        muted: true
      };
    }

    const euro = Number(item.gainEuro);
    const hours = Number(item.gainTempsHeures);
    const fragments = [];

    if (Number.isFinite(hours) && hours > 0) {
      fragments.push(`${formatInteger(hours)} h`);
    }

    if (Number.isFinite(euro) && euro > 0) {
      fragments.push(currencyFormatter.format(Math.round(euro)));
    }

    if (!fragments.length) {
      return {
        value: "Gain à consolider",
        muted: true
      };
    }

    return {
      value: fragments.join(" / "),
      muted: false
    };
  }

  function mapGainTypeLabel(rawType) {
    const normalized = (rawType || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

    if (!normalized) {
      return { label: "Type non renseigné", className: "" };
    }
    if (normalized.includes("temps")) {
      return { label: "Gain de temps", className: "gain-time" };
    }
    if (normalized.includes("cout")) {
      return { label: "Économie", className: "gain-cost" };
    }
    if (normalized.includes("energie")) {
      return { label: "Énergie", className: "gain-energy" };
    }
    if (normalized.includes("simplification")) {
      return { label: "Simplification", className: "gain-simplify" };
    }

    return {
      label: rawType,
      className: ""
    };
  }

  function getGainTypes() {
    const raw = (item.typeGain || item.typeGains || "").toString();
    const parts = raw
      .split(/[,;/|]+/)
      .map((entry) => entry.trim())
      .filter(Boolean);

    if (!parts.length) {
      return [mapGainTypeLabel("")];
    }

    return parts.map(mapGainTypeLabel);
  }

  function renderImage(imageNode, fallbackNode, source, fallbackText) {
    const hasImage = Boolean((source || "").trim());

    if (!hasImage) {
      imageNode.classList.add("hidden");
      imageNode.removeAttribute("src");
      fallbackNode.textContent = fallbackText;
      fallbackNode.classList.remove("hidden");
      return;
    }

    imageNode.onerror = () => {
      imageNode.classList.add("hidden");
      fallbackNode.textContent = fallbackText;
      fallbackNode.classList.remove("hidden");
    };
    imageNode.src = source;
    imageNode.classList.remove("hidden");
    fallbackNode.classList.add("hidden");
  }

  function setPosterMode(enabled) {
    document.body.classList.toggle("poster-mode", enabled && isCompleted);
    els.posterToggleBtn.textContent = document.body.classList.contains("poster-mode") ? "Retour fiche" : "Mode affiche";
  }

  function renderGainBadges() {
    const gainTypes = getGainTypes();
    els.posterTypeBadges.innerHTML = "";

    gainTypes.forEach((entry) => {
      const badge = document.createElement("span");
      badge.className = `poster-type-badge ${entry.className}`.trim();
      badge.textContent = entry.label;
      els.posterTypeBadges.appendChild(badge);
    });
  }

  function render() {
    const title = getTitle();
    const gainDisplay = getGainDisplay();
    const status = statusMeta(item.statut);
    const dateCloture = item.dateCloture ? formatDate(item.dateCloture) : "Non renseignée";

    document.title = `${item.numero || item.id} - ${title}`;

    els.headerMeta.textContent = `${item.numero || item.id} • ${status.label} • ${item.secteur || "Secteur non renseigné"}`;
    els.sheetNumber.textContent = item.numero || item.id || "";
    els.sheetTitle.textContent = title;
    els.metaSecteur.textContent = getText(item.secteur, "Non renseigné");
    els.metaStatus.textContent = status.label;
    els.metaDateOuverture.textContent = item.dateOuverture ? formatDate(item.dateOuverture) : "Non renseignée";
    els.metaDateCloture.textContent = dateCloture;
    els.txtAvant.textContent = getText(item.descriptionAvant || item.avant, "Description avant non renseignée");
    els.txtApres.textContent = getText(item.descriptionApres || item.apres, "Description après non renseignée");
    els.txtConditions.textContent = getText(item.conditionsReussite || item.conditions, "Conditions non renseignées");
    els.txtContributeurs.textContent = getContributorsText();
    els.txtGains.textContent = `${item.typeGain || item.typeGains || "Type non renseigné"} - ${gainDisplay.value}`;

    els.posterNumber.textContent = item.numero || item.id || "";
    els.posterTitle.textContent = title;
    els.posterBeforeText.textContent = getText(item.descriptionAvant || item.avant, "Description avant non renseignée");
    els.posterAfterText.textContent = getText(item.descriptionApres || item.apres, "Description après non renseignée");
    els.posterGainValue.textContent = gainDisplay.value;
    els.posterGainValue.classList.toggle("is-muted", gainDisplay.muted);
    els.posterContributors.textContent = getContributorsText();
    els.posterSecteur.textContent = getText(item.secteur, "Non renseigné");
    els.posterDateCloture.textContent = dateCloture;

    renderImage(els.imgAvant, els.imgAvantFallback, item.imageAvant, "Image avant non disponible");
    renderImage(els.imgApres, els.imgApresFallback, item.imageApres, "Image après non disponible");
    renderImage(els.posterImgAvant, els.posterImgAvantFallback, item.imageAvant, "Visuel avant non disponible");
    renderImage(els.posterImgApres, els.posterImgApresFallback, item.imageApres, "Visuel après non disponible");
    renderGainBadges();

    if (!isCompleted) {
      els.posterLockedNote.textContent = "Le mode affiche est disponible uniquement pour un JDI au statut Complété.";
      els.posterLockedNote.classList.remove("hidden");
      els.posterToggleBtn.disabled = true;
      els.printPosterBtn.disabled = true;
    }

    setPosterMode(initialPosterMode);
  }

  els.backBtn.addEventListener("click", () => {
    navigate("liste.html");
  });

  els.editBtn.addEventListener("click", () => {
    navigate(`formulaire.html?id=${encodeURIComponent(item.id)}`);
  });

  els.posterToggleBtn.addEventListener("click", () => {
    if (!isCompleted) {
      return;
    }

    setPosterMode(!document.body.classList.contains("poster-mode"));
  });

  els.printPosterBtn.addEventListener("click", () => {
    if (!isCompleted) {
      return;
    }

    setPosterMode(true);
    window.setTimeout(() => {
      window.print();
    }, 60);
  });

  render();
})();
