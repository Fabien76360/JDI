(function () {
  const data = window.JDI_DATA || {};
  const common = window.JDI_COMMON || {};
  const items = Array.isArray(data.items) ? data.items : [];
  const configuredSectors = Array.isArray(data.sectors) ? data.sectors : [];
  const navigate = typeof common.navigate === "function"
    ? common.navigate
    : (url) => { window.location.href = url; };
  const numberFormatter = new Intl.NumberFormat("fr-FR");
  const currencyFormatter = new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 0
  });

  const totalCountNode = document.getElementById("totalCount");
  const currentMonthCountNode = document.getElementById("currentMonthCount");
  const globalGainsNode = document.getElementById("globalGains");
  const globalGainsLabelNode = document.getElementById("globalGainsLabel");
  const sectorGridNode = document.getElementById("sectorGrid");
  const newJdiButton = document.getElementById("newJdiBtn");

  function parseIsoDate(isoDate) {
    if (!isoDate) {
      return null;
    }

    const date = new Date(`${isoDate}T00:00:00`);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function isSameMonth(date, referenceDate) {
    return Boolean(
      date &&
      date.getFullYear() === referenceDate.getFullYear() &&
      date.getMonth() === referenceDate.getMonth()
    );
  }

  function formatInteger(value) {
    return numberFormatter.format(Math.round(value || 0));
  }

  function buildSectorCounts() {
    const allSectorNames = Array.from(
      new Set([
        ...configuredSectors,
        ...items.map((item) => item.secteur).filter(Boolean)
      ])
    );

    const counts = allSectorNames.map((sectorName) => ({
      sectorName,
      count: items.filter((item) => item.secteur === sectorName).length
    }));

    return counts.sort((left, right) => {
      if (right.count !== left.count) {
        return right.count - left.count;
      }

      return left.sectorName.localeCompare(right.sectorName, "fr");
    });
  }

  function hasStructuredGain(item) {
    return (
      item &&
      item.gainMode !== "aucun" &&
      Number.isFinite(Number(item.gainEuro)) &&
      Number.isFinite(Number(item.gainTempsHeures))
    );
  }

  function computeGlobalGains() {
    // We only surface gains that are both structured and realized on completed JDI.
    const completedRows = items.filter((item) => item.statut === "Complété" && hasStructuredGain(item));

    if (!completedRows.length) {
      return {
        value: "Gains à consolider",
        label: "Gains globaux sur la période",
        placeholder: true
      };
    }

    const totals = completedRows.reduce((accumulator, item) => ({
      hours: accumulator.hours + Number(item.gainTempsHeures || 0),
      euro: accumulator.euro + Number(item.gainEuro || 0)
    }), { hours: 0, euro: 0 });

    return {
      value: `${formatInteger(totals.hours)} h / ${currencyFormatter.format(Math.round(totals.euro))}`,
      label: "Gains globaux sur la période",
      placeholder: false
    };
  }

  function renderKpis() {
    if (!totalCountNode || !currentMonthCountNode || !globalGainsNode || !globalGainsLabelNode) {
      return;
    }

    const now = new Date();
    const currentMonthCount = items.filter((item) => isSameMonth(parseIsoDate(item.dateOuverture), now)).length;
    const globalGains = computeGlobalGains();

    totalCountNode.textContent = formatInteger(items.length);
    currentMonthCountNode.textContent = formatInteger(currentMonthCount);
    globalGainsNode.textContent = globalGains.value;
    globalGainsLabelNode.textContent = globalGains.label;
    globalGainsNode.classList.toggle("is-placeholder", globalGains.placeholder);
  }

  function renderSectorGrid() {
    if (!sectorGridNode) {
      return;
    }

    // The grid stays data-driven so sector additions/removals do not require HTML edits.
    const sectorCounts = buildSectorCounts();
    sectorGridNode.innerHTML = "";

    if (!sectorCounts.length) {
      const emptyState = document.createElement("div");
      emptyState.className = "info-box dashboard-empty-state";
      emptyState.textContent = "Aucun secteur disponible dans cette maquette.";
      sectorGridNode.appendChild(emptyState);
      return;
    }

    sectorCounts.forEach(({ sectorName, count }) => {
      const tile = document.createElement("button");
      tile.type = "button";
      tile.className = "dashboard-sector-tile";
      tile.innerHTML = `
        <span class="dashboard-sector-name">${sectorName}</span>
        <span class="dashboard-sector-count mono">${formatInteger(count)}</span>
      `;
      tile.addEventListener("click", () => {
        navigate(`liste.html?secteur=${encodeURIComponent(sectorName)}`);
      });
      sectorGridNode.appendChild(tile);
    });
  }

  if (newJdiButton) {
    newJdiButton.addEventListener("click", () => {
      navigate("formulaire.html");
    });
  }

  renderKpis();
  renderSectorGrid();
})();
