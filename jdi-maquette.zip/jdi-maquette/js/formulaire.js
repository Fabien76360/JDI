(function () {
  const data = window.JDI_DATA || {};
  const common = window.JDI_COMMON || {};
  const items = Array.isArray(data.items) ? data.items : [];
  const sectors = Array.isArray(data.sectors) ? data.sectors : [];
  const getQueryParam = typeof common.getQueryParam === "function" ? common.getQueryParam : () => "";
  const navigate = typeof common.navigate === "function"
    ? common.navigate
    : (url) => { window.location.href = url; };
  const editingId = getQueryParam("id");
  const editingItem = items.find((item) => item.id === editingId) || null;
  const todayIso = new Date().toISOString().slice(0, 10);

  const BASE_GAIN_OPTIONS = [
    "Gain de temps",
    "Économie",
    "Simplification",
    "Énergie",
    "Sécurité",
    "Ergonomie"
  ];

  const form = document.getElementById("jdiForm");
  const secteurSelect = document.getElementById("secteur");
  const typeGainSelect = document.getElementById("typeGain");
  const extraToggleBtn = document.getElementById("extraToggleBtn");
  const extraPanel = document.getElementById("extraPanel");

  let isDirty = false;
  const imageState = {
    before: {
      input: document.getElementById("imgAvant"),
      preview: document.getElementById("beforePreview"),
      remove: document.getElementById("removeImgAvantBtn"),
      existingSource: "",
      removed: false
    },
    after: {
      input: document.getElementById("imgApres"),
      preview: document.getElementById("afterPreview"),
      remove: document.getElementById("removeImgApresBtn"),
      existingSource: "",
      removed: false
    }
  };

  function setField(idField, value) {
    const node = document.getElementById(idField);
    if (node) {
      node.value = value === null || value === undefined ? "" : value;
    }
  }

  function normalizeGainType(value) {
    const normalized = (value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();

    if (!normalized) return "";
    if (normalized === "temps" || normalized === "gain de temps") return "Gain de temps";
    if (normalized === "couts" || normalized === "cout" || normalized === "economie") return "Économie";
    if (normalized === "energie") return "Énergie";
    if (normalized === "ergonomie") return "Ergonomie";
    if (normalized === "securite") return "Sécurité";
    if (normalized === "simplification") return "Simplification";

    return value;
  }

  function getUniqueValues(values) {
    return Array.from(new Set(values.filter(Boolean)));
  }

  function populateSectors() {
    sectors.forEach((sector) => {
      const option = document.createElement("option");
      option.value = sector;
      option.textContent = sector;
      secteurSelect.appendChild(option);
    });
  }

  function populateGainTypes() {
    const legacyTypes = (data.gainTypes || []).map(normalizeGainType);
    const currentTypes = editingItem
      ? (editingItem.typeGain || editingItem.typeGains || "")
        .split(/[,;/|]+/)
        .map((entry) => normalizeGainType(entry.trim()))
      : [];
    const options = getUniqueValues([...BASE_GAIN_OPTIONS, ...legacyTypes, ...currentTypes]);

    options.forEach((label) => {
      const option = document.createElement("option");
      option.value = label;
      option.textContent = label;
      typeGainSelect.appendChild(option);
    });
  }

  function setSelectedOptions(selectNode, values) {
    const selected = new Set(values.map(normalizeGainType));
    Array.from(selectNode.options).forEach((option) => {
      option.selected = selected.has(option.value);
    });
  }

  function getSelectedGainTypes() {
    return Array.from(typeGainSelect.selectedOptions).map((option) => option.value);
  }

  function setSystemFields() {
    const status = editingItem ? editingItem.statut || "En cours" : "En cours";
    const openDate = editingItem ? editingItem.dateOuverture || todayIso : todayIso;
    const closeDate = editingItem ? editingItem.dateCloture || "" : "";

    setField("statut", status);
    setField("dateOuverture", openDate);
    setField("dateCloture", closeDate);

    const systemMeta = document.getElementById("systemMeta");
    const formattedOpenDate = openDate ? openDate.split("-").reverse().join("/") : "";
    const formattedCloseDate = closeDate ? closeDate.split("-").reverse().join("/") : "";

    if (status === "Complété" && formattedCloseDate) {
      systemMeta.textContent = `Ouvert le ${formattedOpenDate} • clôturé le ${formattedCloseDate}.`;
    } else {
      systemMeta.textContent = `Ouverture enregistrée automatiquement le ${formattedOpenDate}.`;
    }
  }

  function renderImageCard(slotState, src, altText) {
    slotState.preview.innerHTML = "";

    if (!src) {
      slotState.preview.innerHTML = "<div class='form-image-empty'>Aucune image ajoutée</div>";
      slotState.remove.classList.add("hidden");
      return;
    }

    const card = document.createElement("div");
    card.className = "form-image-card";
    card.innerHTML = `<img src="${src}" alt="${altText}">`;
    slotState.preview.appendChild(card);
    slotState.remove.classList.remove("hidden");
  }

  function bindImageSlot(slotState, altText) {
    slotState.input.addEventListener("change", () => {
      const file = slotState.input.files && slotState.input.files[0];
      slotState.removed = false;

      if (!file) {
        renderImageCard(slotState, slotState.existingSource, altText);
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        renderImageCard(slotState, event.target.result, altText);
      };
      reader.readAsDataURL(file);
      isDirty = true;
    });

    slotState.remove.addEventListener("click", () => {
      slotState.input.value = "";
      slotState.existingSource = "";
      slotState.removed = true;
      renderImageCard(slotState, "", altText);
      isDirty = true;
    });
  }

  function toggleExtraPanel(forceOpen) {
    const willOpen = typeof forceOpen === "boolean" ? forceOpen : extraPanel.classList.contains("hidden");
    extraPanel.classList.toggle("hidden", !willOpen);
    extraToggleBtn.setAttribute("aria-expanded", willOpen ? "true" : "false");
    extraToggleBtn.querySelector(".form-collapse-icon").textContent = willOpen ? "-" : "+";
  }

  function validateGainTypes() {
    if (getSelectedGainTypes().length) {
      typeGainSelect.setCustomValidity("");
    } else {
      typeGainSelect.setCustomValidity("Sélectionne au moins un type de gain.");
    }
  }

  function getInitialGainQuantifie(item) {
    if (!item) return "";
    if ((item.gainQuantifie || "").trim() && item.gainQuantifie !== "N/A") return item.gainQuantifie;
    return "";
  }

  function initializeEditingState() {
    if (!editingItem) {
      document.getElementById("modeLabel").textContent = "Nouveau JDI";
      return;
    }

    document.getElementById("modeLabel").textContent = `Modification ${editingItem.numero}`;
    setField("titre", editingItem.libelle || editingItem.titre);
    setField("secteur", editingItem.secteur);
    setField("descAvant", editingItem.descriptionAvant || editingItem.avant);
    setField("descApres", editingItem.descriptionApres || editingItem.apres);
    setField("contributeurs", editingItem.contributeurs);
    setField("conditions", editingItem.conditionsReussite || editingItem.conditions);
    setField("gainQuantifie", getInitialGainQuantifie(editingItem));

    const selectedTypes = (editingItem.typeGain || editingItem.typeGains || "")
      .split(/[,;/|]+/)
      .map((entry) => entry.trim())
      .filter(Boolean);
    setSelectedOptions(typeGainSelect, selectedTypes);

    imageState.before.existingSource = editingItem.imageAvant || "";
    imageState.after.existingSource = editingItem.imageApres || "";
    renderImageCard(imageState.before, imageState.before.existingSource, "Aperçu avant");
    renderImageCard(imageState.after, imageState.after.existingSource, "Aperçu après");

    if ((editingItem.contributeurs || "").trim() || (editingItem.conditionsReussite || editingItem.conditions || "").trim()) {
      toggleExtraPanel(true);
    }
  }

  function buildPayload() {
    const selectedGainTypes = getSelectedGainTypes();
    const gainText = document.getElementById("gainQuantifie").value.trim();
    const typeGainValue = selectedGainTypes.join(", ");

    return {
      id: editingItem ? editingItem.id : "NOUVEAU",
      numero: editingItem ? editingItem.numero : "",
      libelle: document.getElementById("titre").value.trim(),
      libelleJDI: document.getElementById("titre").value.trim(),
      secteur: document.getElementById("secteur").value,
      ID_Secteur: document.getElementById("secteur").value,
      statut: document.getElementById("statut").value,
      ID_Statut: document.getElementById("statut").value,
      dateOuverture: document.getElementById("dateOuverture").value,
      dateCloture: document.getElementById("dateCloture").value,
      descriptionAvant: document.getElementById("descAvant").value.trim(),
      descriptionApres: document.getElementById("descApres").value.trim(),
      imageAvant: imageState.before.removed ? "" : imageState.before.existingSource,
      imageApres: imageState.after.removed ? "" : imageState.after.existingSource,
      image_descAvant: imageState.before.input.files[0] ? imageState.before.input.files[0].name : (imageState.before.removed ? "" : imageState.before.existingSource),
      image_descApres: imageState.after.input.files[0] ? imageState.after.input.files[0].name : (imageState.after.removed ? "" : imageState.after.existingSource),
      conditionsReussite: document.getElementById("conditions").value.trim(),
      contributeurs: document.getElementById("contributeurs").value.trim(),
      typeGain: typeGainValue,
      typeGains: typeGainValue,
      ID_TypeGains: selectedGainTypes,
      gainQuantifie: gainText,
      gainMode: gainText ? "manuel" : "aucun",
      gainEuro: editingItem ? Number(editingItem.gainEuro || 0) : 0,
      gainTempsHeures: editingItem ? Number(editingItem.gainTempsHeures || 0) : 0,
      gainCommentaire: ""
    };
  }

  function confirmLeave(targetUrl) {
    if (!isDirty || window.confirm("Quitter sans enregistrer les modifications ?")) {
      isDirty = false;
      navigate(targetUrl);
    }
  }

  populateSectors();
  populateGainTypes();
  setSystemFields();
  initializeEditingState();
  renderImageCard(imageState.before, imageState.before.existingSource, "Aperçu avant");
  renderImageCard(imageState.after, imageState.after.existingSource, "Aperçu après");
  bindImageSlot(imageState.before, "Aperçu avant");
  bindImageSlot(imageState.after, "Aperçu après");
  validateGainTypes();

  extraToggleBtn.addEventListener("click", () => {
    toggleExtraPanel();
  });

  form.addEventListener("input", () => {
    isDirty = true;
  });

  form.addEventListener("change", () => {
    isDirty = true;
  });

  typeGainSelect.addEventListener("change", () => {
    validateGainTypes();
  });

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    validateGainTypes();

    if (!form.reportValidity()) {
      return;
    }

    const payload = buildPayload();
    console.log("Simulation enregistrement JDI", payload);
    isDirty = false;
    alert("JDI enregistré (simulation locale).");
    navigate("liste.html");
  });

  document.getElementById("cancelBtn").addEventListener("click", () => {
    confirmLeave("liste.html");
  });

  document.getElementById("secondaryCancelBtn").addEventListener("click", () => {
    confirmLeave("liste.html");
  });

  document.querySelectorAll("a[data-guard='true']").forEach((link) => {
    link.addEventListener("click", (event) => {
      if (!isDirty) return;
      event.preventDefault();
      confirmLeave(link.getAttribute("href"));
    });
  });

  window.addEventListener("beforeunload", (event) => {
    if (!isDirty) return;
    event.preventDefault();
    event.returnValue = "";
  });
})();
